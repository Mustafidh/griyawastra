-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Des 2024 pada 06.18
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `griyawastra`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama_admin` varchar(255) NOT NULL,
  `email_admin` varchar(255) NOT NULL,
  `password_admin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `email_admin`, `password_admin`) VALUES
(1, 'Mustafidh', 'mustafidh@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gambar_produk`
--

CREATE TABLE `gambar_produk` (
  `id_gambar` int(11) NOT NULL,
  `nama_gambar` varchar(255) NOT NULL,
  `id_produk` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `gambar_produk`
--

INSERT INTO `gambar_produk` (`id_gambar`, `nama_gambar`, `id_produk`) VALUES
(3, '6764e1d490cf31.jpeg', 14),
(5, '6764e2969856d.jpeg', 14),
(6, '6764e397773121.jpeg', 15),
(7, '6764e397773122.jpeg', 15),
(8, '6764e4bcd1f751.jpeg', 16),
(9, '6764e4bcd1f752.jpeg', 16),
(10, '6764e61bbfbbf1.jpeg', 4),
(11, '6764e61bbfbbf2.jpeg', 4),
(12, '6764ec1d0ad251.jpeg', 13),
(13, '6764ec1d0ad252.jpeg', 13);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `foto_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `foto_kategori`) VALUES
(1, 'Yogyakarta', 'kjog.jpg'),
(2, 'Surakarta', 'ksol.jpg'),
(3, 'Sunda', 'ksun.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `ukuran` varchar(5) NOT NULL,
  `id_produk` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengembalian`
--

CREATE TABLE `pengembalian` (
  `id_pengembalian` int(11) NOT NULL,
  `id_penyewaan` int(11) NOT NULL,
  `kode_pengembalian` varchar(50) NOT NULL,
  `hari_terlewat` varchar(50) NOT NULL,
  `denda_kerusakan` int(11) NOT NULL,
  `gambar_kondisi` varchar(25) NOT NULL,
  `nama_ekspedisi` varchar(25) NOT NULL,
  `biaya_ekspedisi` int(11) NOT NULL,
  `total_pengembalian` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengembalian`
--

INSERT INTO `pengembalian` (`id_pengembalian`, `id_penyewaan`, `kode_pengembalian`, `hari_terlewat`, `denda_kerusakan`, `gambar_kondisi`, `nama_ekspedisi`, `biaya_ekspedisi`, `total_pengembalian`) VALUES
(28, 21, 'KPG-6760DDF3F29FB', '0 hari', 0, '1734401523_blangkon_1.jpg', 'Layanan Reguler', 7000, 7000),
(29, 22, 'KPG-6760DFB6E0327', '0 hari', 50000, '1734401974_blangkon_1.jpg', 'Layanan Reguler', 7000, 7000),
(30, 23, 'KPG-6760E223D0254', '0 hari', 20000, '1734402595_id-11134207-7r', 'Layanan Reguler', 7000, 7000),
(31, 24, 'KPG-6761162D70524', '0 hari', 0, '1734415917_id-11134207-7r', 'Layanan Reguler', 7000, 7000),
(32, 25, 'KPG-6761173BEAFE5', '0 hari', 2000, '1734416187_id-11134207-7r', 'Layanan Reguler', 7000, 7000),
(33, 26, 'KPG-6764C3188E4FC', '0 hari', 50000, '1734656792_blangkon3.jpg', 'Layanan Reguler', 7000, 7000),
(34, 27, 'KPG-6764D0A683A9B', '0 hari', 2000, '1734660262_id-11134207-7r', 'Layanan Reguler', 7000, 7000),
(35, 27, 'KPG-6764D0EB63985', '0 hari', 2000, '1734660331_blangkon2.jpg', 'Layanan Reguler', 7000, 7000),
(36, 28, 'KPG-6764D290458C3', '0 hari', 2000, '1734660752_blangkon2.jpg', 'Layanan Reguler', 7000, 7000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_pengguna` varchar(255) NOT NULL,
  `email_pengguna` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `no_ktp` varchar(16) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `kode_kab_kota` int(11) NOT NULL,
  `nama_kab_pengguna` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_pengguna`, `email_pengguna`, `password`, `no_ktp`, `no_hp`, `alamat`, `kode_kab_kota`, `nama_kab_pengguna`) VALUES
(1, 'Adi', 'adi@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '3403041234567123', '0836373623', 'Salam, Patuk', 135, 'Gunung Kidul'),
(2, 'Notowijoyo', 'notowijoyo@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '3403041234567123', '0876859585884', 'Notowijayan', 501, 'Yogyakarta');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyewaan`
--

CREATE TABLE `penyewaan` (
  `id_penyewaan` int(11) NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `kode_transaksi` varchar(50) NOT NULL,
  `tgl_penyewaan` datetime NOT NULL,
  `tgl_kembali` datetime NOT NULL,
  `durasi_sewa` varchar(50) NOT NULL,
  `status_penyewaan` enum('Belum Bayar','Diproses','Dikirim','Disewa','Proses Verifikasi','Diverifikasi','Selesai','Dibatalkan') NOT NULL,
  `resi_ekspedisi` varchar(50) NOT NULL,
  `layanan_ekspedisi` varchar(100) NOT NULL,
  `nama_ekspedisi` varchar(100) NOT NULL,
  `biaya_ekspedisi` int(11) NOT NULL,
  `estimasi_ekspedisi` varchar(100) NOT NULL,
  `total_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penyewaan`
--

INSERT INTO `penyewaan` (`id_penyewaan`, `id_pengguna`, `kode_transaksi`, `tgl_penyewaan`, `tgl_kembali`, `durasi_sewa`, `status_penyewaan`, `resi_ekspedisi`, `layanan_ekspedisi`, `nama_ekspedisi`, `biaya_ekspedisi`, `estimasi_ekspedisi`, `total_harga`) VALUES
(21, 1, 'PGW-6760DD8093331', '2024-12-20 00:00:00', '2024-12-21 00:00:00', '1 hari', 'Selesai', '', 'JNE', 'Layanan Reguler', 10000, '1-2', 18000),
(22, 1, 'PGW-6760DF5E1832F', '2024-12-20 00:00:00', '2024-12-21 00:00:00', '1 hari', 'Selesai', '', 'JNE', 'Layanan Reguler', 10000, '1-2', 18000),
(23, 1, 'PGW-6760E1D610ABE', '2024-12-19 00:00:00', '2024-12-21 00:00:00', '2 hari', 'Selesai', '', 'JNE', 'Layanan Reguler', 10000, '1-2', 54000),
(24, 1, 'PGW-6760E495AF8AC', '2024-12-20 00:00:00', '2024-12-21 00:00:00', '1 hari', 'Diverifikasi', 'JN123456789', 'JNE', 'Layanan Reguler', 10000, '1-2', 18000),
(25, 1, 'PGW-6761165F51CB9', '2024-12-12 00:00:00', '2024-12-20 00:00:00', '8 hari', 'Diverifikasi', 'JN123456789', 'JNE', 'Layanan Reguler', 10000, '1-2', 122000),
(26, 1, 'PGW-6764C2866D567', '2024-12-21 00:00:00', '2024-12-23 00:00:00', '2 hari', 'Selesai', 'JN123456789', 'JNE', 'Layanan Reguler', 10000, '1-2', 26000),
(27, 1, 'PGW-6764D0607C9FF', '2024-12-21 00:00:00', '2024-12-23 00:00:00', '2 hari', 'Selesai', 'JN123456789', 'JNE', 'Layanan Reguler', 10000, '1-2', 38000),
(28, 1, 'PGW-6764D1CDB0C6E', '2024-12-21 00:00:00', '2024-12-22 00:00:00', '1 hari', 'Selesai', 'JN1234567890', 'JNE', 'Layanan Reguler', 10000, '1-2', 27500);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyewaan_detail`
--

CREATE TABLE `penyewaan_detail` (
  `id_penyewaan_detail` int(11) NOT NULL,
  `id_penyewaan` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `nama_sewa` varchar(250) NOT NULL,
  `harga_satuan` int(11) NOT NULL,
  `jumlah_sewa` int(11) NOT NULL,
  `ukuran_sewa` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penyewaan_detail`
--

INSERT INTO `penyewaan_detail` (`id_penyewaan_detail`, `id_penyewaan`, `id_produk`, `nama_sewa`, `harga_satuan`, `jumlah_sewa`, `ukuran_sewa`) VALUES
(22, 21, 4, 'Blangkon Gagrak Yogyakarta', 8000, 1, 'S'),
(23, 22, 4, 'Blangkon Gagrak Yogyakarta', 8000, 1, 'S'),
(24, 23, 4, 'Blangkon Gagrak Yogyakarta', 8000, 1, 'S'),
(26, 24, 4, 'Blangkon Gagrak Yogyakarta', 8000, 1, 'M'),
(28, 26, 19, 'Lurik Hijau', 8000, 1, 'M'),
(29, 27, 19, 'Lurik Hijau', 8000, 1, 'M'),
(30, 27, 15, 'Blangkon Batik Hitam', 6000, 1, 'M'),
(31, 28, 16, 'Blangkon Batik Biru', 5500, 1, 'L'),
(32, 28, 5, 'Beskap Gagrak Solo', 12000, 1, 'M');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `deskripsi_produk` text NOT NULL,
  `harga_sewa` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `ukuran_produk` varchar(50) DEFAULT NULL,
  `foto_produk` varchar(255) NOT NULL,
  `berat_produk` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `deskripsi_produk`, `harga_sewa`, `stok`, `ukuran_produk`, `foto_produk`, `berat_produk`, `id_kategori`, `id_admin`) VALUES
(4, 'Blangkon Putih Tulang Pinggiran Ulo Gunung Yogyakarta', 'Blangkon adalah sebutan untuk penutup kepala tradisional yang digunakan pria sebagai pelengkap pakaian adat Jawa atau Jawa. Blangkon Yogyakarta memiliki beberapa bagian yang terdiri dari wiron, kuncung, tengahan, sintingan, kepet, dan mondolan. ', 8000, 10, NULL, '6764e61bbfbbf.jpeg', 80, 1, 1),
(5, 'Beskap Payet Hijau Yogyakarta', 'Bahan kualitas terbaik dari solo, Jawa Tengah', 13000, 10, NULL, '6764ef8103b87.jpeg', 60, 1, 1),
(6, 'Kebaya Hitam Yogyakarta', 'Kebaya Hitam', 15000, 12, NULL, '6764f5b276589.jpeg', 50, 1, 1),
(7, 'Beskap Payet Biru Yogyakarta', 'Beskap bahan katun nyaman dan elegan', 14000, 10, NULL, '6764efeb7f43d.jpeg', 50, 1, 1),
(8, 'Beskap Beskap Hewes Hijau Sage Yogyakarta', 'Beskap bahan katun berkualitas', 14000, 8, NULL, '6764ee934c255.jpeg', 60, 1, 1),
(11, 'Beskap Hewes Tosca Yogyakarta', 'Beskap mewah untuk acara khusus', 14000, 3, NULL, '6764eec47a427.jpeg', 65, 1, 1),
(12, 'Beskap Payet Abu Solo', 'Beskap tradisional dengan bahan nyaman', 13000, 6, NULL, '6764ef1aa0dd2.jpeg', 60, 2, 1),
(13, 'Blangkon Gagrak Solo', 'Blangkon eksklusif dengan desain elegan', 8000, 4, NULL, '6764ec1d0ad25.jpeg', 55, 2, 1),
(14, 'Blangkon Hijau Polkadot Larasati Yogyakarta', 'Blangkon dengan motif batik tradisional', 8000, 20, NULL, '6764e1d490cf3.jpeg', 100, 1, 1),
(15, 'Blangkon Kembang Gedang Modang Yogyakarta', 'Blangkon warna hitam dengan batik elegan', 8000, 15, NULL, '6764e39777312.jpeg', 60, 1, 1),
(16, 'Blangkon Slewah Mrutu Sewu Yogyakarta', 'Blangkon dengan motif batik biru yang indah', 9000, 18, NULL, '6764e4bcd1f75.jpeg', 50, 1, 1),
(17, 'Kebaya Kuning Yogyakarta', 'Kebaya Kuning Yogyakarta', 15000, 12, NULL, '6764f5ea7206b.jpeg', 60, 1, 1),
(18, 'Kebaya Biru Dongker Yogyakarta', 'Kebaya dengan warna biru menyala', 7500, 10, NULL, '6764fb85720ed.jpeg', 110, 1, 1),
(19, 'Kebaya Biru Muda Yogyakarta', 'Lurik dengan warna biru segar', 14000, 14, NULL, '6764fbc87b8c1.jpeg', 60, 1, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `ulasan`
--

CREATE TABLE `ulasan` (
  `id_ulasan` int(11) NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `komentar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `gambar_produk`
--
ALTER TABLE `gambar_produk`
  ADD PRIMARY KEY (`id_gambar`),
  ADD KEY `id_produk` (`id_produk`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id_keranjang`),
  ADD KEY `id_pengguna` (`id_pengguna`,`id_produk`),
  ADD KEY `id_produk` (`id_produk`);

--
-- Indeks untuk tabel `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD PRIMARY KEY (`id_pengembalian`),
  ADD KEY `id_penyewaan` (`id_penyewaan`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indeks untuk tabel `penyewaan`
--
ALTER TABLE `penyewaan`
  ADD PRIMARY KEY (`id_penyewaan`),
  ADD KEY `id_pengguna` (`id_pengguna`);

--
-- Indeks untuk tabel `penyewaan_detail`
--
ALTER TABLE `penyewaan_detail`
  ADD PRIMARY KEY (`id_penyewaan_detail`),
  ADD KEY `id_penyewaan` (`id_penyewaan`),
  ADD KEY `id_produk` (`id_produk`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`),
  ADD KEY `id_kategori` (`id_kategori`,`id_admin`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indeks untuk tabel `ulasan`
--
ALTER TABLE `ulasan`
  ADD PRIMARY KEY (`id_ulasan`),
  ADD KEY `id_pengguna` (`id_pengguna`,`id_produk`),
  ADD KEY `id_produk` (`id_produk`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `gambar_produk`
--
ALTER TABLE `gambar_produk`
  MODIFY `id_gambar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id_keranjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT untuk tabel `pengembalian`
--
ALTER TABLE `pengembalian`
  MODIFY `id_pengembalian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `penyewaan`
--
ALTER TABLE `penyewaan`
  MODIFY `id_penyewaan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `penyewaan_detail`
--
ALTER TABLE `penyewaan_detail`
  MODIFY `id_penyewaan_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `ulasan`
--
ALTER TABLE `ulasan`
  MODIFY `id_ulasan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `gambar_produk`
--
ALTER TABLE `gambar_produk`
  ADD CONSTRAINT `gambar_produk_ibfk_1` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `keranjang`
--
ALTER TABLE `keranjang`
  ADD CONSTRAINT `keranjang_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `keranjang_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD CONSTRAINT `pengembalian_ibfk_2` FOREIGN KEY (`id_penyewaan`) REFERENCES `penyewaan` (`id_penyewaan`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `penyewaan`
--
ALTER TABLE `penyewaan`
  ADD CONSTRAINT `penyewaan_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `penyewaan_detail`
--
ALTER TABLE `penyewaan_detail`
  ADD CONSTRAINT `penyewaan_detail_ibfk_1` FOREIGN KEY (`id_penyewaan`) REFERENCES `penyewaan` (`id_penyewaan`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `penyewaan_detail_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `produk_ibfk_1` FOREIGN KEY (`id_admin`) REFERENCES `admin` (`id_admin`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `produk_ibfk_2` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `ulasan`
--
ALTER TABLE `ulasan`
  ADD CONSTRAINT `ulasan_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id_pengguna`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `ulasan_ibfk_2` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
