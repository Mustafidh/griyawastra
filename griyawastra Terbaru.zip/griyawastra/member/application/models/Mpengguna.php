<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mpengguna extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Mendapatkan data pengguna berdasarkan email
     * @param string $email
     * @return object|null
     */
    public function get_pengguna_by_email($email) {
        // Cek apakah input email tidak kosong
        if (empty($email)) {
            return null;
        }

        // Query ke tabel pengguna berdasarkan email
        $this->db->where('email_pengguna', $email);
        $result = $this->db->get('pengguna');

        // Mengembalikan hasil dalam bentuk baris tunggal (objek)
        return $result->row();
    }

    public function get_detail($id_pengguna) {
        $this->db->select('id_pengguna, nama_pengguna, email_pengguna, kode_kab_kota, alamat, nama_kab_pengguna');
        $this->db->from('pengguna');
        $this->db->where('id_pengguna', $id_pengguna);
        $query = $this->db->get();
    
        if ($query->num_rows() > 0) {
            return $query->row_array(); // Mengembalikan data dalam bentuk array
        } else {
            return null; // Tidak ada data ditemukan
        }
    }

    public function cek_admin($id_pengguna) {
        return $this->db->get_where('admin', ['id_admin' => $id_pengguna])->row();
    }

    /**
     * Mengupdate data pengguna
     * @param string $email
     * @param array $data
     * @return bool
     */
    public function update_pengguna($email, $data) {
        // Cek apakah email dan data yang diberikan tidak kosong
        if (empty($email) || empty($data)) {
            return false;
        }

        // Update data pengguna berdasarkan email
        $this->db->where('email_pengguna', $email);
        return $this->db->update('pengguna', $data);
    }

    /**
     * Menambahkan data pengguna baru
     * @param array $data
     * @return bool
     */
    public function insert_pengguna($data) {
        return $this->db->insert('pengguna', $data);
    }

}
