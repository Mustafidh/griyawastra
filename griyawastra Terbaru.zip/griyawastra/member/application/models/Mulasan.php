<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mulasan extends CI_Model {
    // Ambil ulasan berdasarkan ID produk, limit 3 ulasan terbaru
    public function get_ulasan_by_produk($id_produk, $limit = 3) {
        $this->db->select('ulasan.*, pengguna.nama_pengguna'); // Pilih kolom yang diinginkan
        $this->db->from('ulasan');
        $this->db->join('pengguna', 'ulasan.id_pengguna = pengguna.id_pengguna'); // Join dengan tabel pengguna
        $this->db->where('ulasan.id_produk', $id_produk);
        $this->db->order_by('ulasan.id_ulasan', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }
    

    // Hitung rata-rata rating untuk produk
    public function get_avg_rating($id_produk) {
        $this->db->select_avg('rating');
        $this->db->where('id_produk', $id_produk);
        return $this->db->get('ulasan')->row()->rating;
    }

    // Hitung total ulasan untuk produk
    public function count_ulasan($id_produk) {
        $this->db->where('id_produk', $id_produk);
        return $this->db->count_all_results('ulasan');
    }


    private $table = 'ulasan';

    // Method untuk menyimpan ulasan secara batch
    public function insert_batch($data)
    {
        return $this->db->insert_batch($this->table, $data);
    }
}
