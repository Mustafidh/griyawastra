<?php
class Mongkir extends CI_Model {
   
    function tampil_distrik(){

    $curl = curl_init();
    
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://api.rajaongkir.com/starter/city",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_HTTPHEADER => array(
        "key: fab8a22cf34aa948b0e3b96b45833a93"
      ),
    ));
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      $responsi = json_decode($response,TRUE);
      return $responsi["rajaongkir"]["results"];
    }
        }
        
        function detail_distrik($city_id){
          $curl = curl_init();
    
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://api.rajaongkir.com/starter/city?id=$city_id",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_HTTPHEADER => array(
        "key: fab8a22cf34aa948b0e3b96b45833a93"
      ),
    ));
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      $responsi = json_decode($response,TRUE);
      return $responsi["rajaongkir"]["results"];
    }
        }
      
        public function biaya($origin, $destination, $weight) {
          $curl = curl_init();
      
          curl_setopt_array($curl, array(
              CURLOPT_URL => "https://api.rajaongkir.com/starter/cost",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => http_build_query([
                  'origin' => $origin,
                  'destination' => $destination,
                  'weight' => $weight,
                  'courier' => 'jne'
              ]),
              CURLOPT_HTTPHEADER => array(
                  "Content-Type: application/x-www-form-urlencoded",
                  "key: fab8a22cf34aa948b0e3b96b45833a93"
              ),
          ));
      
          $response = curl_exec($curl);
          $err = curl_error($curl);
      
          curl_close($curl);
      
          if ($err) {
              echo "cURL Error #:" . $err;
              return array(); 
          } else {
              $response = json_decode($response, TRUE);
    
              if (isset($response['rajaongkir']['status']['code']) && $response['rajaongkir']['status']['code'] == 200) {
                  if (!empty($response['rajaongkir']['results'][0])) {
                      return $response['rajaongkir']['results'][0];
                  } else {
                      echo "Data pengiriman tidak ditemukan.";
                      return array();
                  }
              } else {
                  echo "Error dari API: " . $response['rajaongkir']['status']['description'];
                  return array();
              }
          }
      }
      
  }