<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mpengembalian extends CI_Model {
    /**
     * Fungsi untuk mengunggah gambar kondisi
     */

   /*  public function get_pengembalian_by_id($id_penyewaan) {
        $this->db->where('id_penyewaan', $id_penyewaan);
        $query = $this->db->get('pengembalian');
        return $query->row_array();
    } */

    public function get_penyewaan_by_pengembalian($id_penyewaan) {
        $this->db->select('penyewaan.*');
        $this->db->from('penyewaan');
        $this->db->join('pengembalian', 'pengembalian.id_penyewaan = penyewaan.id_penyewaan');
        $this->db->where('pengembalian.id_penyewaan', $id_penyewaan);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_pengembalian_by_id($id_penyewaan) {
        $this->db->select('*, (total_pengembalian + IFNULL(denda_kerusakan, 0)) as total_final_pengembalian');
        $this->db->from('pengembalian');
        $this->db->where('id_penyewaan', $id_penyewaan);
        $query = $this->db->get();
    
        return $query->row_array();
    }
    
    
    /**
     * Fungsi untuk menyimpan data pengembalian
     */
    public function insert_pengembalian($data)
    {
        return $this->db->insert('pengembalian', $data);
    }

    public function update_status_penyewaan($id_penyewaan) {
        $this->db->where('id_penyewaan', $id_penyewaan);
        $this->db->set('status_penyewaan', 'Proses Verifikasi');
        return $this->db->update('penyewaan');
    }

    function set_selesai($id_penyewaan){
        $this->db->where('id_penyewaan', $id_penyewaan);
        $this->db->set("status_penyewaan", "Selesai");
        $this->db->update('penyewaan');
    }


}
