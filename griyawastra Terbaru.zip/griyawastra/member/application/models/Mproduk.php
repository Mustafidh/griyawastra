<?php
class Mproduk extends CI_Model {
    function tampil(){
        $this->db->select('produk.*, kategori.nama_kategori');
        $this->db->from('produk');
        $this->db->join('kategori', 'kategori.id_kategori = produk.id_kategori');
        $q = $this->db->get();
        $d = $q->result_array();
        return $d;
    }
    
    function tampil_produk_terbaru(){
        $this->db->select('produk.*, kategori.nama_kategori');
        $this->db->from('produk');
        $this->db->join('kategori', 'kategori.id_kategori = produk.id_kategori');
        $this->db->order_by('id_produk', 'desc');
        $this->db->limit(6);  // Ambil 4 produk terbaru
        $q = $this->db->get();
        $d = $q->result_array();
        return $d;
    }

    function get_total_rows() {
        return $this->db->count_all("produk");
    }

    function detail_umum($id_produk) {
        $this->db->select('produk.*, kategori.nama_kategori');
        $this->db->from('produk');
        $this->db->join('kategori', 'produk.id_kategori = kategori.id_kategori', 'left');
        $this->db->where('produk.id_produk', $id_produk);
        $q = $this->db->get();
        return $q->row_array();
    }

    function get_all_produk_except($id_produk) {
        $this->db->select('produk.*, kategori.nama_kategori');
        $this->db->from('produk');
        $this->db->join('kategori', 'produk.id_kategori = kategori.id_kategori', 'left');
        $this->db->where('produk.id_produk !=', $id_produk);
        $q = $this->db->get();
        return $q->result_array();
    }
    

    function calculate_similarity($produk_terpilih, $produk_list) {
        $similarities = [];
        $terpilih_tokens = $this->tokenize($produk_terpilih);

        foreach ($produk_list as $produk) {
            $produk_tokens = $this->tokenize($produk['nama_produk']);
            $similarity = $this->cosine_similarity($terpilih_tokens, $produk_tokens);
            $similarities[] = [
                'produk' => $produk,
                'similarity' => $similarity
            ];
        }

        // Urutkan berdasarkan similarity (desc)
        usort($similarities, function($a, $b) {
            return $b['similarity'] <=> $a['similarity'];
        });

        // Batasi hanya 3 produk teratas
        return array_slice($similarities, 0, 3);
    }

    function tokenize($text) {
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9\s]/', '', $text);
        return array_count_values(explode(' ', $text));
    }

    function cosine_similarity($tokens1, $tokens2) {
        $dot_product = 0;
        $magnitude1 = 0;
        $magnitude2 = 0;

        $all_tokens = array_unique(array_merge(array_keys($tokens1), array_keys($tokens2)));

        foreach ($all_tokens as $token) {
            $dot_product += (isset($tokens1[$token]) ? $tokens1[$token] : 0) * (isset($tokens2[$token]) ? $tokens2[$token] : 0);
            $magnitude1 += pow(isset($tokens1[$token]) ? $tokens1[$token] : 0, 2);
            $magnitude2 += pow(isset($tokens2[$token]) ? $tokens2[$token] : 0, 2);
        }

        $magnitude1 = sqrt($magnitude1);
        $magnitude2 = sqrt($magnitude2);

        return ($magnitude1 * $magnitude2) ? ($dot_product / ($magnitude1 * $magnitude2)) : 0;
    }
    
    
    function detail($id_produk){
        $this->db->where('id_pengguna', $this->session->userdata("id_pengguna"));
        $this->db->where('id_produk', $id_produk);
        $this->db->join('kategori', 'produk.id_kategori = kategori.id_kategori', 'left');
        $q = $this->db->get("produk");
        $d = $q->row_array();

        return $d;
    }

    public function get_gambar_tambahan($id_produk)
{
    $this->db->where('id_produk', $id_produk);
    return $this->db->get('gambar_produk')->result_array();
}
    
    function ubah($inputan, $id){
        $config['upload_path'] = $this->config->item("assets_produk");
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        
        $this->load->library('upload', $config);
        $ngupload = $this->upload->do_upload("foto_produk");
        
        if ($ngupload) {
            $inputan['foto_produk'] = $this->upload->data("file_name");
        }
        $inputan['id_member'] = $this->session->userdata("id_member");

        $this->db->where('id_member', $this->session->userdata("id_member"));
        $this->db->where('id_produk', $id);
        $this->db->update('produk', $inputan);
    }

    function hapus($id_produk){
        $this->db->where('id_member', $this->session->userdata("id_member"));
        $this->db->where('id_produk', $id_produk);
        $this->db->delete('produk');
    }

  /*  function detail_umum($id_produk){
        $this->db->where('id_produk', $id_produk);
        $this->db->join('kategori', 'produk.id_kategori = kategori.id_kategori', 'left');
        $q = $this->db->get("produk");
        $d = $q->row_array();

        return $d; */
    
}