<?php
class Mpenyewaan extends CI_Model {

    // Ambil data penyewaan berdasarkan ID
    public function get_penyewaan_by_id($id_penyewaan) {
        $this->db->where('id_penyewaan', $id_penyewaan);
        $query = $this->db->get('penyewaan');
        return $query->row_array();
    }

    // Insert data penyewaan
    public function insert_penyewaan($data_penyewaan) {
        $this->db->insert('penyewaan', $data_penyewaan);
        return $this->db->insert_id(); // Mengembalikan ID penyewaan baru
    }
    

    // Update status penyewaan menjadi 'Diproses'
    public function set_diproses($id_penyewaan) {
        $this->db->where('id_penyewaan', $id_penyewaan);
        $this->db->set('status_penyewaan', 'Diproses');
        return $this->db->update('penyewaan');
    }

    // Insert detail penyewaan berdasarkan item yang dipilih
    public function insert_detail_penyewaan($id_penyewaan, $selected_items) {
        // Ambil data keranjang untuk item yang dipilih
        $this->load->model('Mkeranjang');
        $keranjang = $this->Mkeranjang->get_selected_items($selected_items);

        if (!$keranjang) {
            return false; // Jika keranjang kosong, kembalikan false
        }

        // Insert setiap item ke penyewaan_detail
        foreach ($keranjang as $item) {
            $data_detail = array(
                'id_penyewaan' => $id_penyewaan,
                'id_produk' => $item['id_produk'],
                'nama_sewa' => $item['nama_produk'],
                'harga_satuan' => $item['harga_sewa'],
                'jumlah_sewa' => $item['jumlah'],
                'ukuran_sewa' => $item['ukuran']
            );

            if (!$this->db->insert('penyewaan_detail', $data_detail)) {
                return false; // Jika satu saja gagal, kembalikan false
            }
        }

        return true; // Jika semua berhasil, kembalikan true
    }

    // Ambil detail produk berdasarkan ID penyewaan
    public function get_produk_by_penyewaan($id_penyewaan) {
        $this->db->select('pd.id_penyewaan_detail, pd.id_penyewaan, pd.id_produk, p.nama_produk, p.foto_produk, p.berat_produk, pd.jumlah_sewa, pd.ukuran_sewa, pd.harga_satuan');
        $this->db->from('penyewaan_detail pd');
        $this->db->join('produk p', 'pd.id_produk = p.id_produk');
        $this->db->where('pd.id_penyewaan', $id_penyewaan);
        $query = $this->db->get();
        return $query->result_array();
    }

    // Ambil semua penyewaan berdasarkan ID pengguna
    public function getPenyewaanByUserId($id_pengguna) {
        $this->db->select('*');
        $this->db->from('penyewaan');
        $this->db->where('id_pengguna', $id_pengguna);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function tampil($limit, $start, $id_pengguna) {
        $this->db->where('id_pengguna', $id_pengguna);
        $this->db->limit($limit, $start);
        return $this->db->get('penyewaan')->result_array();
    }

    public function get_total_rows() {
        return $this->db->count_all("penyewaan");
    }
    
    public function get_total_rows_by_user($id_pengguna) {
        $this->db->where('id_pengguna', $id_pengguna);
        return $this->db->count_all_results('penyewaan');
    }
}
?>
