<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mkeranjang extends CI_Model {

    // Menambahkan produk ke keranjang
    public function tambah_ke_keranjang($data) {
        $this->db->where('id_pengguna', $data['id_pengguna']);
        $this->db->where('id_produk', $data['id_produk']);
        $this->db->where('ukuran', $data['ukuran']); // Tambahkan pengecekan ukuran
    
        $existing = $this->db->get('keranjang')->row();
    
        if ($existing) {
            // Update jumlah jika sudah ada dengan ukuran sama
            $this->db->set('jumlah', 'jumlah + ' . $data['jumlah'], FALSE);
            $this->db->where('id_keranjang', $existing->id_keranjang);
            return $this->db->update('keranjang');
        } else {
            // Tambahkan sebagai entri baru
            return $this->db->insert('keranjang', $data);
        }
    }

    // Mengambil semua produk dalam keranjang untuk pengguna tertentu
    public function ambil_keranjang($id_pengguna) {
        return $this->db->select('keranjang.id_keranjang, keranjang.ukuran, keranjang.jumlah, produk.nama_produk, produk.harga_sewa, produk.foto_produk')
                        ->from('keranjang')
                        ->join('produk', 'keranjang.id_produk = produk.id_produk')
                        ->where('keranjang.id_pengguna', $id_pengguna)
                        ->get()
                        ->result();
    }
    

    // Menghapus produk dari keranjang
    public function hapus_dari_keranjang($id_keranjang) {
        $this->db->where('id_keranjang', $id_keranjang);
        return $this->db->delete('keranjang');
    }

    // Mengupdate jumlah produk di keranjang
    public function update_jumlah($id_keranjang, $jumlah) {
        $this->db->set('jumlah', $jumlah);
        $this->db->where('id_keranjang', $id_keranjang);
        return $this->db->update('keranjang');
    }
    
    public function update_ukuran($id_keranjang, $ukuran) {
        $this->db->set('ukuran', $ukuran);
        $this->db->where('id_keranjang', $id_keranjang);
        return $this->db->update('keranjang');
    }

    public function get_keranjang_by_user($id_pengguna) {
        $this->db->where('id_pengguna', $id_pengguna);
        return $this->db->get('keranjang')->result_array();
    }

    // Ambil data keranjang berdasarkan ID yang dipilih
     public function get_selected_items($selected_items) {
        $this->db->select('keranjang.*, produk.nama_produk, produk.harga_sewa, produk.berat_produk, produk.foto_produk');
            $this->db->from('keranjang');
            $this->db->join('produk', 'keranjang.id_produk = produk.id_produk', 'left');
            $this->db->where_in('keranjang.id_keranjang', $selected_items);
            $query = $this->db->get();
            return $query->result_array();
        }
    
    // Ambil harga produk berdasarkan ID produk
    public function get_harga_produk($id_produk) {
        $this->db->select('harga_sewa');
        $this->db->where('id_produk', $id_produk);
        $query = $this->db->get('produk');
        $result = $query->row_array();
        return $result['harga_sewa'] ?? 0;
    }

    public function get_nama_produk($id_produk) {
        $this->db->select('nama_produk');
        $this->db->where('id_produk', $id_produk);
        $query = $this->db->get('produk');
        $result = $query->row_array();
        return $result['nama_produk'] ?? '';
    }

    public function save_penyewaan($data) {
        $this->db->insert('penyewaan', $data);
        return $this->db->insert_id();
    }

    public function delete_selected_items($selected_items) {
        $this->db->where_in('id_keranjang', $selected_items);
        $this->db->delete('keranjang');
    }
    
    
    public function get_berat_produk($id_produk)
{
    $this->db->select('berat_produk');
    $this->db->from('produk');
    $this->db->where('id_produk', $id_produk);
    $query = $this->db->get();

    if ($query->num_rows() > 0) {
        return $query->row()->berat; // Mengembalikan berat produk
    } else {
        return 0; // Jika data tidak ditemukan, kembalikan 0
    }
}
}
