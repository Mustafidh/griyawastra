<?php
class Produk extends CI_Controller {

    function index(){

    $this->load->model("Mproduk");
    $this->load->model("Mkategori");
    $this->load->library('pagination');

    $data['kategori'] = $this->Mkategori->tampil();

        $per_page = 6; // Jumlah data per halaman
        $total_rows = $this->Mproduk->get_total_rows();
    
        $config['base_url'] = site_url('produk/index');
        $config['total_rows'] = $total_rows;
        $config['per_page'] = $per_page;
        $config['uri_segment'] = 3;
    
        // Custom Styling Pagination
        $config['full_tag_open'] = '<ul class="pagination justify-content-center" style="gap: 10px;">';
        $config['full_tag_close'] = '</ul>';
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" style="color: #ffffff; background-color: #187444; border: 1px solid #187444; padding: 8px 16px; border-radius: 50px;">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['attributes'] = array('class' => 'page-link', 'style' => 'color: #187444; background-color: #ffffff; border: 1px solid #ddd; padding: 8px 16px; border-radius: 50px;');
    
        $this->pagination->initialize($config);
    
        $offset = $this->uri->segment(3, 0);
        $data['produk'] = $this->Mproduk->tampil($per_page, $offset);
        $data['pagination'] = $this->pagination->create_links();

        $query = $this->input->get('query'); // Ambil kueri pencarian dari URL
        if ($query) {
            // Mencari produk berdasarkan nama produk
            $this->db->like('nama_produk', $query);
            $q = $this->db->get('produk');
            $data['produk'] = $q->result_array();
        } else {
            // Jika tidak ada kueri pencarian, ambil semua produk
            $data['produk'] = $this->db->get('produk')->result_array();
        }

       $this->load->view("header");
       $this->load->view("produk", $data);
       $this->load->view("footer");
    }

    public function detail($id_produk) {
    $this->load->model("Mproduk");
    $this->load->model("Mulasan");

    // Ambil data detail produk
    $data["produk"] = $this->Mproduk->detail_umum($id_produk);
    $data['gambar_tambahan'] = $this->Mproduk->get_gambar_tambahan($id_produk);

    // Ambil ulasan dan rating produk
    $data["reviews"] = $this->Mulasan->get_ulasan_by_produk($id_produk);
    $data["avg_rating"] = $this->Mulasan->get_avg_rating($id_produk);
    $data["total_reviews"] = $this->Mulasan->count_ulasan($id_produk);

    // Proses rekomendasi produk berdasarkan judul
    $produk_terpilih = $data["produk"]["nama_produk"]; // Judul produk yang sedang dilihat
    $produk_list = $this->Mproduk->get_all_produk_except($id_produk); // Produk lain

    // Hitung similarity dan dapatkan rekomendasi
    $data['recommended_produk'] = $this->Mproduk->calculate_similarity($produk_terpilih, $produk_list);

    // Proses data dari form ulasan
    $inputan = $this->input->post();
    if ($inputan) {
        if (isset($inputan['rating']) && isset($inputan['komentar'])) {
            $ulasan_data = [
                'id_pengguna' => $this->session->userdata('id_pengguna'), // Sesuaikan dengan sistem login Anda
                'id_produk' => $id_produk,
                'rating' => $inputan['rating'],
                'komentar' => $inputan['komentar']
            ];
            $this->Mulasan->simpan_ulasan($ulasan_data);
            $this->session->set_flashdata('pesan_sukses', 'Ulasan Anda berhasil disimpan!');
            redirect('produk/detail/' . $id_produk);
        } else {
            // Proses penyimpanan keranjang jika bukan ulasan
            $this->load->model("Mkeranjang");
            $this->Mkeranjang->simpan($inputan, $id_produk);
            $this->session->set_flashdata('pesan_sukses', 'Produk masuk ke keranjang belanja');
            redirect('', 'refresh');
        }
    }
 
    $this->load->view("header");
    $this->load->view("produk_detail", $data);
    $this->load->view("footer");
}

  
}