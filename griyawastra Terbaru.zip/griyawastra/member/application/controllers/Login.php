<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Mpengguna');
        $this->load->library(['session', 'form_validation']);
    }

    public function index() {
        $this->load->view('header');
        $this->load->view('login');
        $this->load->view('footer');
    }

    public function proses_login() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email', [
            'required' => 'Kolom %s wajib diisi.',
            'valid_email' => 'Kolom %s harus berisi email yang valid.'
        ]);
        $this->form_validation->set_rules('password', 'Password', 'required', [
            'required' => 'Kolom %s wajib diisi.'
        ]);
    
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('header');
            $this->load->view('login');
            $this->load->view('footer');
        } else {
            $email = $this->input->post('email');
            $password = sha1($this->input->post('password'));
    
            $pengguna = $this->Mpengguna->get_pengguna_by_email($email);
    
            if ($pengguna && $password === $pengguna->password) {
                // Periksa apakah pengguna adalah admin
                $is_admin = $this->Mpengguna->cek_admin($pengguna->id_admin);
    
                if ($is_admin) {
                    // Jika admin, arahkan ke folder admin di luar aplikasi
                    $this->session->set_userdata([
                        'id_pengguna' => $pengguna->id_admin,
                        'nama_pengguna' => $pengguna->nama_admin,
                        'email_pengguna' => $pengguna->email_admin,
                        'logged_in' => TRUE,
                        'is_admin' => TRUE
                    ]);
                    redirect('/admin'); // Arahkan 
                } else {
                    // Jika bukan admin, arahkan ke halaman welcome
                    $is_profil_lengkap = !empty($pengguna->no_ktp) && !empty($pengguna->alamat) && !empty($pengguna->kode_kab_kota);
                    $this->session->set_userdata([
                        'id_pengguna' => $pengguna->id_pengguna,
                        'nama_pengguna' => $pengguna->nama_pengguna,
                        'email_pengguna' => $pengguna->email_pengguna,
                        'logged_in' => TRUE,
                        'profil_lengkap' => $is_profil_lengkap
                    ]);
                    $this->session->set_flashdata('pesan_sukses', 'Login berhasil! Selamat datang di Griya Wastra.');
                    redirect('welcome');
                }
            } else {
                $this->session->set_flashdata('pesan_gagal', 'Email atau Password salah.');
                redirect('login');
            }
        }
    }
    

    public function logout() {
        $this->session->sess_destroy();
        redirect('login');
    }
}
