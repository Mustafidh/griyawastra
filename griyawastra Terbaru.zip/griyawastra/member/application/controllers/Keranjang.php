<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keranjang extends CI_Controller {

   public function __construct() {
      parent::__construct();
      // Load model dan library yang diperlukan
      $this->load->model('Mpengguna'); // Pastikan Mpengguna sudah benar
      $this->load->model('Mkeranjang');
      $this->load->model('Mongkir');
      $this->load->library(['session', 'form_validation']);
  }
    // Menampilkan halaman keranjang
    public function index() {
        $id_pengguna = $this->session->userdata('id_pengguna');
        $data['keranjang'] = $this->Mkeranjang->ambil_keranjang($id_pengguna);
        $this->load->view('header');
        $this->load->view('keranjang', $data);
        $this->load->view('footer');
    }

    // Menambahkan produk ke keranjang
    public function tambah() {
      $id_produk = $this->input->post('id_produk');
      $jumlah = $this->input->post('jumlah');
      $ukuran = $this->input->post('ukuran'); // Ukuran baju
      $id_pengguna = $this->session->userdata('id_pengguna');
  
      $data = [
          'id_pengguna' => $id_pengguna,
          'id_produk' => $id_produk,
          'jumlah' => $jumlah,
          'ukuran' => $ukuran
      ];
  
      if ($this->Mkeranjang->tambah_ke_keranjang($data)) {
          $this->session->set_flashdata('pesan_sukses', 'Produk berhasil ditambahkan ke keranjang');
      } else {
          $this->session->set_flashdata('pesan_error', 'Terjadi kesalahan, silakan coba lagi');
      }
      redirect('keranjang');
  }
  

    // Menghapus produk dari keranjang
    public function hapus($id_keranjang) {
        if ($this->Mkeranjang->hapus_dari_keranjang($id_keranjang)) {
            $this->session->set_flashdata('pesan_sukses', 'Produk berhasil dihapus dari keranjang');
        } else {
            $this->session->set_flashdata('pesan_error', 'Terjadi kesalahan, silakan coba lagi');
        }
        redirect('keranjang');
    }

    // Mengupdate jumlah produk dalam keranjang
    public function update_jumlah() {
      $id_keranjang = $this->input->post('id_keranjang');
      $jumlah = $this->input->post('jumlah');
      
      if ($this->Mkeranjang->update_jumlah($id_keranjang, $jumlah)) {
          echo json_encode(['status' => 'success']);
      } else {
          echo json_encode(['status' => 'error']);
      }
  }
  
  public function update_ukuran() {
      $id_keranjang = $this->input->post('id_keranjang');
      $ukuran = $this->input->post('ukuran');
      
      if ($this->Mkeranjang->update_ukuran($id_keranjang, $ukuran)) {
          echo json_encode(['status' => 'success']);
      } else {
          echo json_encode(['status' => 'error']);
      }
  }

  public function lakukan_sewa() {
    $selected_items = $this->input->post('selected_items'); // Ambil data checkbox
    if ($selected_items) {
        // Simpan ID keranjang yang dipilih ke session
        $this->session->set_userdata('selected_items', $selected_items);
        redirect('keranjang/sewa');
    } else {
        $this->session->set_flashdata('pesan_gagal', 'Tidak ada item yang dipilih.');
        redirect('keranjang');
    }
}

// Halaman pengisian detail penyewaan
public function sewa() {
    $this->load->model(['Mkeranjang', 'Mpengguna', 'Mongkir']);

    $id_pengguna = $this->session->userdata('id_pengguna');
    if (!$id_pengguna) {
        redirect('login'); // Pastikan pengguna login
    }

    $selected_items = $this->session->userdata('selected_items');
    if (!$selected_items) {
        redirect('keranjang'); // Kembali ke keranjang jika tidak ada item yang dipilih
    }

    $data['keranjang'] = $this->Mkeranjang->get_selected_items($selected_items);

    $total_berat = 0;
    foreach ($data['keranjang'] as $item) {
        $total_berat += $item['jumlah'] * $item['berat_produk'];
    }

    // Ambil data pengguna (asal dan tujuan)
    $data['pengguna'] = $this->Mpengguna->get_detail($id_pengguna);

    $origin = 501; // Kode kota asal (contoh: kode kota toko Anda)
    $destination = $data['pengguna']['kode_kab_kota'];

    $response = $this->Mongkir->biaya($origin, $destination, $total_berat);

    // Hitung biaya pengiriman
    $data['biaya'] = $this->Mongkir->biaya($origin, $destination, $total_berat);

    $this->form_validation->set_rules("ongkir", "Ongkir", "required");
    $this->form_validation->set_message("required", "%s wajib diisi");

    if ($this->form_validation->run() == TRUE) {
        $ongkir = $this->input->post("ongkir");
        $ongkir_terpilih = $data['biaya']['costs'][$ongkir];

        // Data untuk checkout/penyewaan
        $id_transaksi = $this->Mkeranjang->checkout(
            $data['keranjang'],
            $data['pengguna'],
            $data['biaya']['name'],
            $ongkir_terpilih
        );

        $this->session->set_flashdata('pesan_sukses', 'Penyewaan berhasil diproses');
        redirect('transaksi/detail/' . $id_transaksi, 'refresh');
    }

    $this->load->view('header');
    $this->load->view('penyewaan', $data);
    $this->load->view('footer');
}

}



