<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengembalian extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Mpengembalian');
    }

    public function simpan()
    {
        // Validasi input
        $this->form_validation->set_rules('id_penyewaan', 'ID Penyewaan', 'required|integer');
        $this->form_validation->set_rules('hari_terlewat', 'Hari Terlewat', 'required');
        $this->form_validation->set_rules('nama_ekspedisi', 'Nama Ekspedisi', 'required');
        $this->form_validation->set_rules('biaya_ekspedisi', 'Biaya Ekspedisi', 'required|integer');
        $this->form_validation->set_rules('total_pengembalian', 'Total Pengembalian', 'required|integer');

        if (empty($_FILES['gambar_kondisi']['name'])) {
            $this->form_validation->set_rules('gambar_kondisi', 'Gambar Kondisi', 'required');
        }

        if ($this->form_validation->run() == FALSE) {
            // Jika validasi gagal
            $response = [
                'status' => false,
                'message' => validation_errors()
            ];
        } else {
            // Upload file gambar
            $config['upload_path'] = $this->config->item("assets_kondisi");
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $config['file_name'] = uniqid();

            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('gambar_kondisi')) {
                $response = [
                    'status' => false,
                    'message' => $this->upload->display_errors()
                ];
            } else {
                // Data yang akan disimpan
                $upload_data = $this->upload->data();
                $kode_pengembalian = 'KPG-' . strtoupper(uniqid());
                $data = [
                    'id_penyewaan' => $this->input->post('id_penyewaan'),
                    'kode_pengembalian' =>  $kode_pengembalian,
                    'hari_terlewat' => $this->input->post('hari_terlewat'),
                    'gambar_kondisi' => $upload_data['file_name'],
                    'nama_ekspedisi' => $this->input->post('nama_ekspedisi'),
                    'biaya_ekspedisi' => $this->input->post('biaya_ekspedisi'),
                    'total_pengembalian' => $this->input->post('total_pengembalian'),
                ];

                // Simpan ke database
                if ($this->Mpengembalian->insert_pengembalian($data)) {
                    $response = [
                        'status' => true,
                    ];
                    
                    // Hanya panggil update jika penyimpanan berhasil
                    if ($this->Mpengembalian->update_status_penyewaan($data['id_penyewaan'])) {
                        $response['update_status'] = true;
                    } else {
                        $response['update_status'] = false;
                    }
                    // Jika berhasil, tampilkan SweetAlert dan redirect
                    $this->session->set_flashdata('pesan_sukses', 'Pengembalian sedang dalam verifikasi!');
                    redirect('penyewaan/daftar_sewa', 'refresh');
                } else {
                    $response = [
                        'status' => false,
                        'message' => 'Gagal menyimpan data pengembalian.'
                    ];
                }
            }
        }

        // Tampilkan respon dalam format JSON
        echo json_encode($response);
        
    }


    function verifikasi($id_penyewaan){


        $this->load->model('Mpengembalian');
         $this->load->model('Mpenyewaan');
        $this->load->model('Mpengguna');
        
        $id_pengguna = $this->session->userdata('id_pengguna');

        $data['pengguna'] = $this->Mpengguna->get_detail($id_pengguna);
        $data['penyewaan'] = $this->Mpenyewaan->get_penyewaan_by_id($id_penyewaan);
        $data['pengembalian'] = $this->Mpengembalian->get_pengembalian_by_id($id_penyewaan);
        $data['produk'] = $this->Mpenyewaan->get_produk_by_penyewaan($id_penyewaan);

        if ($data['penyewaan']['status_penyewaan'] == "Diverifikasi") {
        $snapToken = "";
          $data["cekmidtrans"] = array();
          include 'midtrans-php/Midtrans.php';
          \Midtrans\Config::$serverKey = 'SB-Mid-server-YKNfUyKsbUesxPMo__9G1jgR';
          \Midtrans\Config::$isProduction = false;
          \Midtrans\Config::$isSanitized = true;
          \Midtrans\Config::$is3ds = true;


          $params['transaction_details']['order_id'] = $data['penyewaan']['id_penyewaan'];
          $params['transaction_details']['gross_amount'] = $data['pengembalian']['total_final_pengembalian'];
          
          try {
              $snapToken = \Midtrans\Snap::getSnapToken($params);
          } catch (Exception $e) {

          }
          $data["snapToken"] = $snapToken;
    
          $curl = curl_init();
          curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.sandbox.midtrans.com/v2/". $data['penyewaan']['id_penyewaan'] . "/status",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
              "accept: application/json","authorization: Basic 
              U0ItTWlkLXNlcnZlci1ZS05mVXlLc2JVZXN4UE1vX185RzFqZ1I6TXVzdGFmaWRoMzEwNA=="
            ),
          ));
          
          $response = curl_exec($curl);
          $err = curl_error($curl);
          
          curl_close($curl);
          
          if ($err) {
            echo "cURL Error #:" . $err;
          } else {
            $responsi = json_decode($response,TRUE);
              if (isset($responsi['status_code']) && in_array($responsi["status_code"], [200, 201])) {
                  $data["cekmidtrans"] = $responsi;

                  if($responsi['transaction_status']=="settlement"){
                    $this->Mpengembalian->set_selesai($id_penyewaan);
                    redirect('penyewaan/tampil_ulasan/'.$id_penyewaan,'refresh');
                  }
              }
          }
        }

        $this->load->view("header");
        $this->load->view("verifikasi", $data);
        $this->load->view("footer");
     }
}
