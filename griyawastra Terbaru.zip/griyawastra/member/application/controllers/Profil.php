<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model(['Mpengguna', 'Mongkir']);
        $this->load->library(['session', 'form_validation']);
    }

    public function index() {
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
        }

        $email_pengguna = $this->session->userdata('email_pengguna');
        $pengguna = $this->Mpengguna->get_pengguna_by_email($email_pengguna);

        $data['username'] = $pengguna->nama_pengguna ?? '';
        $data['email'] = $pengguna->email_pengguna ?? '';
        $data['alamat'] = $pengguna->alamat ?? '';
        $data['ktp'] = $pengguna->no_ktp ?? '';
        $data['phone'] = $pengguna->no_hp ?? '';
        $data['password'] = '';
        $data['province_code'] = $pengguna->kode_kab_kota ?? '';
        $data['nama_kab_pengguna'] = $pengguna->nama_kab_pengguna ?? '';

        $data['distrik'] = $this->Mongkir->tampil_distrik();

        if ($this->input->post()) {
            $this->form_validation->set_rules('username', 'Nama Pengguna', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('address', 'Alamat', 'required');
            $this->form_validation->set_rules('phone', 'No. Telepon', 'required');
            $this->form_validation->set_rules('ktp', 'No. KTP', 'required|numeric|min_length[16]|max_length[16]');
            $this->form_validation->set_rules('province', 'Kabupaten/Provinsi', 'required');

            if (!empty($this->input->post('password'))) {
                $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
            }

            if ($this->form_validation->run() == TRUE) {
                $province_code = $this->input->post('province');
                $kabupaten_name = $this->get_kabupaten_name($province_code);
                $password = !empty($this->input->post('password')) ? sha1($this->input->post('password')) : $pengguna->password;

                $updated_data = [
                    'nama_pengguna' => $this->input->post('username'),
                    'email_pengguna' => $this->input->post('email'),
                    'alamat' => $this->input->post('address'),
                    'no_hp' => $this->input->post('phone'),
                    'no_ktp' => $this->input->post('ktp'),
                    'kode_kab_kota' => $province_code,
                    'nama_kab_pengguna' => $kabupaten_name,
                    'password' => $password
                ];

                $this->Mpengguna->update_pengguna($email_pengguna, $updated_data);

                $is_profil_lengkap = !empty($updated_data['no_ktp']) && !empty($updated_data['alamat']) && !empty($updated_data['kode_kab_kota']);
                $this->session->set_userdata('profil_lengkap', $is_profil_lengkap);

                $this->session->set_flashdata('pesan_sukses', 'Data berhasil diperbarui.');
                redirect('welcome');
            }
        }

        $this->load->view('header');
        $this->load->view('profil', $data);
        $this->load->view('footer');
    }

    private function get_kabupaten_name($province_code) {
        $distrik = $this->Mongkir->tampil_distrik();
        foreach ($distrik as $kabupaten) {
            if ($kabupaten['city_id'] == $province_code) {
                return $kabupaten['city_name'];
            }
        }
        return '';
    }
}
