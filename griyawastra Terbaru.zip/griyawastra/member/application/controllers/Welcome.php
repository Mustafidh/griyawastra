<?php

class Welcome extends CI_Controller {

    function index()
    {
        // Validasi form login (opsional)
        $inputan = $this->input->post();
        $this->form_validation->set_rules("email_member", "Email", "required");
        $this->form_validation->set_rules("password_member", "Password", "required");
        $this->form_validation->set_message("required", "%s wajib diisi");
        
        if ($this->form_validation->run() == TRUE) {
            $this->load->model('Mmember');
            $output = $this->Mmember->login($inputan);
            if ($output == "ada") {
                $this->session->set_flashdata('pesan_sukses', "Berhasil Login");
                redirect('Home', 'refresh');
            } else {
                $this->session->set_flashdata('pesan_gagal', "Gagal Login");
                redirect('/', 'refresh');
            }
        }

        // Memuat helper dan model
        $this->load->helper('url');
        $this->load->model('Mkategori');
        $this->load->model('Mproduk');
        $this->load->model('Martikel');
        
        // Ambil data dari model
        $data['kategori'] = $this->Mkategori->tampil();
        $data['produk'] = $this->Mproduk->tampil_produk_terbaru();  // Ambil produk terbaru

        // Kirim data ke view
        $this->load->view('header');
        $this->load->view('home', $data);  // Kirim data produk ke view 'home'
        $this->load->view('footer');
    }
}
