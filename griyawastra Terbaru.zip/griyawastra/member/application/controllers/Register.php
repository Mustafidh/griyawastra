<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load model dan library yang diperlukan
        $this->load->model('Mpengguna'); // Pastikan Mpengguna sudah benar
        $this->load->library(['session', 'form_validation']);
    }

    // Halaman utama registrasi
    public function index() {
        $this->load->view('header'); // View header
        $this->load->view('register'); // View form register
        $this->load->view('footer'); // View footer
    }

    // Proses registrasi
    public function proses_register() {
        // Aturan validasi
        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[pengguna.nama_pengguna]', [
            'required' => 'Kolom %s wajib diisi.',
            'is_unique' => '%s sudah digunakan.'
        ]);
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[pengguna.email_pengguna]', [
            'required' => 'Kolom %s wajib diisi.',
            'valid_email' => 'Kolom %s harus berisi email yang valid.',
            'is_unique' => '%s sudah digunakan.'
        ]);
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]', [
            'required' => 'Kolom %s wajib diisi.',
            'min_length' => '%s minimal harus berisi 6 karakter.'
        ]);

        // Jika validasi gagal
        if ($this->form_validation->run() == FALSE) {
            // Tampilkan kembali halaman registrasi dengan error
            $this->load->view('header');
            $this->load->view('register');
            $this->load->view('footer');
        } else {
            // Jika validasi berhasil
            $data = [
                'nama_pengguna' => $this->input->post('username'), // Username
                'email_pengguna' => $this->input->post('email'),   // Email
                'password' => sha1($this->input->post('password')), // Password di-hashing menggunakan SHA-1
            ];

            // Simpan data pengguna ke database
            if ($this->Mpengguna->insert_pengguna($data)) {
                // Set session logged_in dan data pengguna
                $this->session->set_userdata([
                    'logged_in' => true,
                    'email_pengguna' => $data['email_pengguna'], // Simpan email ke session
                    'nama_pengguna' => $data['nama_pengguna']   // Simpan username ke session
                ]);

                // Set pesan sukses dan redirect ke halaman profil
                $this->session->set_flashdata('pesan_sukses', 'Registrasi berhasil! Silahkan lengkapi data profil anda!.');
                redirect('profil'); // Pastikan controller Profil tersedia
            } else {
                // Jika gagal, set pesan error dan arahkan kembali ke halaman register
                $this->session->set_flashdata('pesan_gagal', 'Terjadi kesalahan. Silakan coba lagi.');
                redirect('register');
            }
        }
    }
}
