<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penyewaan extends CI_Controller {

    public function simpan() {

        $this->load->model('Mpenyewaan');
        $this->load->model('Mkeranjang');
        $this->load->model('Mpengguna');

        // Ambil data dari session dan input form
        $id_pengguna = $this->session->userdata('id_pengguna');
        $selected_items = $this->session->userdata('selected_items'); // Item yang dipilih
        if (!$selected_items) {
            redirect('keranjang'); // Kembali ke keranjang jika tidak ada item yang dipilih
        }
    
        $tgl_penyewaan = $this->input->post('tgl_penyewaan');
        $tgl_kembali = $this->input->post('tgl_kembali');
        $durasi_sewa = $this->input->post('durasi_sewa');
        $nama_ekspedisi = $this->input->post('nama_ekspedisi');
        $biaya_ekspedisi = $this->input->post('biaya_ekspedisi');
        $estimasi_ekspedisi = $this->input->post('estimasi_ekspedisi');
        $total_harga = $this->input->post('total_harga');
    
        // Auto-generate kode transaksi
        $kode_transaksi = 'PGW-' . strtoupper(uniqid());
    
        // Data untuk tabel penyewaan
        $data_penyewaan = array(
            'id_pengguna' => $id_pengguna,
            'kode_transaksi' => $kode_transaksi,
            'tgl_penyewaan' => $tgl_penyewaan,
            'tgl_kembali' => $tgl_kembali,
            'durasi_sewa' => $durasi_sewa,
            'status_penyewaan' => 'Belum Bayar',
            'resi_ekspedisi' => '',
            'layanan_ekspedisi' => 'JNE',
            'nama_ekspedisi' => $nama_ekspedisi,
            'biaya_ekspedisi' => $biaya_ekspedisi,
            'estimasi_ekspedisi' => $estimasi_ekspedisi,
            'total_harga' => $total_harga,
        );
    
        // Simpan data penyewaan ke tabel penyewaan
        $id_penyewaan = $this->Mpenyewaan->insert_penyewaan($data_penyewaan);
        if (!$id_penyewaan) {
            // Gagal menyimpan data penyewaan
            $this->session->set_flashdata('error', 'Terjadi kesalahan saat menyimpan data penyewaan.');
            redirect('penyewaan');
            return;
        }
    
        // Ambil data keranjang untuk item yang dipilih
        $keranjang = $this->Mkeranjang->get_selected_items($selected_items); // Sesuaikan model Mkeranjang
    
        // Simpan data ke tabel penyewaan_detail
        $result = $this->Mpenyewaan->insert_detail_penyewaan($id_penyewaan, $selected_items);
    
        if (!$result) {
            $this->session->set_flashdata('error', 'Terjadi kesalahan saat menyimpan detail penyewaan.');
            redirect('penyewaan');
        }
        $this->Mkeranjang->delete_selected_items($selected_items);
    
    
        // Jika berhasil, arahkan ke halaman sukses atau pembayaran
        $this->session->set_flashdata('success', 'Penyewaan berhasil disimpan. Silakan lanjutkan ke pembayaran.');
        redirect('penyewaan/detail/' . $id_penyewaan);
    }

    


    public function detail($id_penyewaan) {
        $this->load->model('Mpenyewaan');
        $this->load->model('Mpengguna');


        if (empty($id_penyewaan)) {
            show_error('ID penyewaan tidak ditemukan.', 404);
        }
    
        $id_pengguna = $this->session->userdata('id_pengguna'); // Pastikan session id_pengguna ada
        if (empty($id_pengguna)) {
            show_error('Pengguna tidak ditemukan.', 404);
        }
    
        // Ambil data penyewaan berdasarkan id_penyewaan
        $data['penyewaan'] = $this->Mpenyewaan->get_penyewaan_by_id($id_penyewaan);

        if (empty($data['penyewaan'])) {
            show_error('Data penyewaan tidak ditemukan.', 404);
        }
    
        $data['pengguna'] = $this->Mpengguna->get_detail($id_pengguna);
        $data['produk'] = $this->Mpenyewaan->get_produk_by_penyewaan($id_penyewaan);
    
        $snapToken = "";
        $data["cekmidtrans"] = array();
    
        if ($data['penyewaan']['status_penyewaan'] == "Belum Bayar") {
            include 'midtrans-php/Midtrans.php';
            \Midtrans\Config::$serverKey = 'SB-Mid-server-YKNfUyKsbUesxPMo__9G1jgR';
            \Midtrans\Config::$isProduction = false;
            \Midtrans\Config::$isSanitized = true;
            \Midtrans\Config::$is3ds = true;
    
            $params['transaction_details']['order_id'] = $data['penyewaan']['kode_transaksi']; // Gunakan id_penyewaan
            $params['transaction_details']['gross_amount'] = $data['penyewaan']['total_harga'];
    
            try {
                $snapToken = \Midtrans\Snap::getSnapToken($params);
            } catch (Exception $e) {
                // Handle exception
            }
            $data["snapToken"] = $snapToken;
    
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.sandbox.midtrans.com/v2/" . $data["penyewaan"]["kode_transaksi"] . "/status",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array(
                    "accept: application/json",
                    "authorization: Basic U0ItTWlkLXNlcnZlci1ZS05mVXlLc2JVZXN4UE1vX185RzFqZ1I6TXVzdGFmaWRoMzEwNA=="
                ),
            ));
    
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
    
            if ($err) {
                echo "cURL Error #:" . $err;
            } else {
                $responsi = json_decode($response, TRUE);
                if (isset($responsi['status_code']) && in_array($responsi["status_code"], [200, 201])) {
                    $data["cekmidtrans"] = $responsi;
    
                    if ($responsi['transaction_status'] == "settlement") {
                        $this->Mpenyewaan->set_diproses($id_penyewaan);
                        redirect('penyewaan/detail/' . $id_penyewaan, 'refresh');
                    }
                }
            }
        }
    
        $this->load->view('header');
        $this->load->view('penyewaan_detail', $data);
        $this->load->view('footer');
    }
    
    
    public function daftar_sewa() {
        $this->load->model('Mpenyewaan');
        $this->load->library('pagination');

        $id_pengguna = $this->session->userdata('id_pengguna');

        $per_page = 5; // Jumlah data per halaman
        $total_rows = $this->Mpenyewaan->get_total_rows_by_user($id_pengguna);
    
        $config['base_url'] = site_url('penyewaan/daftar_sewa');
        $config['total_rows'] = $total_rows;
        $config['per_page'] = $per_page;
        $config['uri_segment'] = 3;
    
        // Custom Styling Pagination
        $config['full_tag_open'] = '<ul class="pagination justify-content-center" style="gap: 5px;">';
        $config['full_tag_close'] = '</ul>';
        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tag_close'] = '</li>';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" style="color: #ffffff; background-color: #187444; border: 1px solid #187444; padding: 8px 16px; border-radius: 50px;">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['attributes'] = array('class' => 'page-link', 'style' => 'color: #187444; background-color: #ffffff; border: 1px solid #ddd; padding: 8px 16px; border-radius: 50px;');
    
        $this->pagination->initialize($config);
    
        $offset = $this->uri->segment(3, 0);
        $data['penyewaan'] = $this->Mpenyewaan->tampil($per_page, $offset, $id_pengguna);
        $data['pagination'] = $this->pagination->create_links();
        $data['start_no'] = $offset + 1;
    
        $this->load->view('header');
        $this->load->view('daftar_sewa', $data);
        $this->load->view('footer');
    }    

    public function pengembalian($id_penyewaan) {
        $this->load->model('Mpenyewaan');
        $this->load->model('Mpengguna');
        $this->load->model('Mongkir');
    
        // Validasi parameter $id_penyewaan
        if (empty($id_penyewaan)) {
            show_error('ID penyewaan tidak ditemukan.', 404);
        }
    
        // Pastikan pengguna telah login
        $id_pengguna = $this->session->userdata('id_pengguna');
        if (empty($id_pengguna)) {
            show_error('Pengguna tidak ditemukan.', 404);
        }
    
        // Ambil data penyewaan
        $data['penyewaan'] = $this->Mpenyewaan->get_penyewaan_by_id($id_penyewaan);
        if (empty($data['penyewaan'])) {
            show_error('Data penyewaan tidak ditemukan.', 404);
        }
    
        // Ambil data produk beserta beratnya
        $data['produk'] = $this->Mpenyewaan->get_produk_by_penyewaan($id_penyewaan);
    
        // Hitung total berat
        $total_berat = 0;
        foreach ($data['produk'] as $item) {
            // Pastikan data berat_produk tersedia
            if (isset($item['berat_produk'], $item['jumlah_sewa'])) {
                $total_berat += $item['berat_produk'] * $item['jumlah_sewa'];
            }
        }
    
        // Ambil detail pengguna
        $data['pengguna'] = $this->Mpengguna->get_detail($id_pengguna);
    
        // Hitung ongkir
        $origin = $data['pengguna']['kode_kab_kota'];
        $destination = 501; // Tujuan (contoh: kode Yogyakarta)
        $data['biaya'] = $this->Mongkir->biaya($origin, $destination, $total_berat);
    
        // Validasi form
        $this->form_validation->set_rules("ongkir", "Ongkir", "required");
        $this->form_validation->set_message("required", "%s wajib diisi");
    
        if ($this->form_validation->run() == TRUE) {
            $ongkir = $this->input->post("ongkir");
    
            // Ambil data biaya ongkir yang dipilih
            $ongkir_terpilih = $data['biaya']['costs'][$ongkir] ?? null;
            if ($ongkir_terpilih) {
                $this->session->set_flashdata('pesan_sukses', 'Penyewaan berhasil diproses');
                redirect('transaksi/detail/' . $id_penyewaan, 'refresh');
            } else {
                $this->session->set_flashdata('pesan_error', 'Ongkir tidak valid.');
            }
        }
    
        // Tampilkan view
        $this->load->view('header');
        $this->load->view('pengembalian', $data);
        $this->load->view('footer');
    }

    public function ulasan()
    {

        $this->load->model('Mulasan'); // Memuat model Mulasan
        $this->load->library('session');

        // Pastikan data POST diterima
        $postData = $this->input->post();
        if (empty($postData)) {
            $this->session->set_flashdata('error', 'Data ulasan tidak valid.');
            redirect('penyewaan');
        }

        // Ambil ID pengguna dari session (sesuaikan dengan aplikasi Anda)
        $id_pengguna = $this->session->userdata('id_pengguna');

        // Loop data ulasan dan simpan ke database
        $dataToInsert = [];
        foreach ($postData['id_produk'] as $index => $id_produk) {
            $dataToInsert[] = [
                'id_pengguna' => $id_pengguna,
                'id_produk'   => $id_produk,
                'rating'      => $postData['rating'][$id_produk],
                'komentar'    => $postData['ulasan'][$id_produk]
            ];
        }

        // Simpan data menggunakan model
        $isInserted = $this->Mulasan->insert_batch($dataToInsert);

        if ($isInserted) {
            $this->session->set_flashdata('pesan_sukses', 'Terimakasih telah memberi penilaian.');
        } else {
            $this->session->set_flashdata('error', 'Terjadi kesalahan saat menyimpan ulasan.');
        }

        redirect('penyewaan/daftar_sewa');
    }

    public function tampil_ulasan($id_penyewaan)
    {
        $this->load->model('Mproduk');
        $this->load->model('Mpenyewaan'); 
        $this->load->model('Mulasan');
        $this->load->library('session');

        $data['produk'] = $this->Mpenyewaan->get_produk_by_penyewaan($id_penyewaan); // Ambil semua ulasan

        $this->load->view('header');
        $this->load->view('ulasan', $data); 
        $this->load->view('footer');
    }
}