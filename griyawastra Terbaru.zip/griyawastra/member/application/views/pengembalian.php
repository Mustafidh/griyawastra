
<main>
      <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px;">
        <div class="mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 600px;">
          <h2 class="form-title mt-2">Pengembalian Pakaian</h2>
          <form action="<?php echo base_url('pengembalian/simpan'); ?>" method="post" enctype="multipart/form-data">
          <!-- Product Card -->
          <?php foreach ($produk as $item): ?>
                <div class="product-card mb-2">
                <img src="<?= $this->config->item('url_uploads') . $item['foto_produk']; ?>" alt="<?= $item['nama_sewa']; ?>" class="me-3" style="width: 80px; height: 80px; object-fit: cover;">
                    <div class="product-info">
                        <p><strong><?php echo $item['nama_produk']; ?></strong></p>
                        <p class="card-text">Jumlah: <span class="text-success"><?php echo $item['jumlah_sewa']; ?></span></p>
                        <p class="card-text">Ukuran: <span class="text-success"><?php echo $item['ukuran_sewa']; ?></span></p>
                        <p class="card-text fw-bold">Harga/Hari: <span class="text-success">Rp. <?php echo number_format($item['harga_satuan']); ?></span></p>
                        <input type="hidden" name="id_produk[]" value="<?php echo $item['id_produk']; ?>"> <!-- Menyimpan ID produk ke dalam form -->
                    </div>
                </div>
            <?php endforeach; ?>
            
            <!-- Rental Dates -->
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="startDate" class="form-label" style="font-weight: 500;">Tanggal Awal Sewa</label>
                <input type="date" class="form-control" id="startDate" name="tgl_penyewaan" 
                value="<?php echo isset($penyewaan['tgl_penyewaan']) ? date('Y-m-d', strtotime($penyewaan['tgl_penyewaan'])) : ''; ?>" readonly>
              </div>
              <div class="col-md-6">
                <label for="endDate" class="form-label" style="font-weight: 500;">Tanggal Kembali</label>
                <input type="date" class="form-control" id="endDate" name="tgl_kembali" 
                value="<?php echo isset($penyewaan['tgl_kembali']) ? date('Y-m-d', strtotime($penyewaan['tgl_kembali'])) : ''; ?>" readonly>
              </div>
            </div>
            
            <div class="mb-3">
                <label for="address" class="form-label" style="font-weight: 500;">Alamat Toko Kami</label>
                <input type="text" class="form-control" id="address" value="Tunjungbiru, Wilutama, Gondokusuman, Yogyakarta 51362" readonly>
            </div>

            <!-- Address -->
            <div class="mb-3">
                <label for="address" class="form-label" style="font-weight: 500;">Alamat Pengguna</label>
                <input type="text" class="form-control" id="address" value="<?php echo $pengguna['alamat'] . ', ' . $pengguna['nama_kab_pengguna']; ?>" readonly>
            </div>

            <!-- Courier -->
            <label for="ongkir" class="form-label" style="font-weight: 500;">Opsi Pengiriman</label>
                <select class="form-control mb-3" name="ongkir" required>
                    <option value="">Pilih</option>
                    <?php foreach ($biaya['costs'] as $key => $value): ?>
                        <option value="<?php echo $key ?>"
                                data-name="<?php echo $value['description']; ?>"
                                data-etd="<?php echo $value['cost'][0]['etd']; ?>"
                                data-cost="<?php echo $value['cost'][0]['value']; ?>">
                            <p>
                                <strong><?php echo $value['description']; ?></strong> |<br>
                                Rp. <?php echo number_format($value['cost'][0]['value'], 0, ',', '.'); ?> |<br>
                                <?php echo $value['cost'][0]['etd']; ?> Hari
                            </p>
                        </option>
                    <?php endforeach ?>
                </select>
            
            <div class="mb-3">
                <label for="status" class="form-label" style="font-weight: 500;">Status</label>
                <input type="text" class="form-control" id="address" value="<?php echo $penyewaan['status_penyewaan']; ?>" readonly>
            </div>
                
            <div class="mb-3">
                <label for="gambar_kondisi" class="form-label" style="font-weight: 500;">Gambar Kondisi Pakaian</label>
                <input type="file" class="form-control" id="gambar_kondisi" name="gambar_kondisi" accept="image/*" style="border-radius: 5px; border: 1px solid #ddd;" required>
            </div>


            <!-- Payment Details -->
            <div class="total-payment bg-light p-3 rounded border d-flex justify-content-between align-items-center">
            <div class="left-info">
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Keterlambatan</p>
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Denda Kerusakan</p>
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Ongkir</p>
                <p id="totalPriceElement" style="margin: 0; font-weight: bold; font-size: 1rem;" class="fw-bolder">Total</p>
            </div>
            <div class="right-info text-end">
            <input type="hidden" name="id_penyewaan" value="<?php echo $penyewaan['id_penyewaan']; ?>">
            <input type="hidden" name="hari_terlewat" id="totalLateDaysElementHidden" value="">
            <input type="hidden" name="total_pengembalian" id="totalPriceElementHidden" value="">
            <input type="hidden" name="biaya_ekspedisi" id="shippingCostElementHidden" value="">
            <input type="hidden" name="nama_ekspedisi" id="shippingDescriptionHidden" value="">

                <p id="totalLateDaysElementText" style="margin: 0; font-size: 0.9rem;">0 hari</p>
                <p style="margin: 0; font-size: 0.9rem;">Rp. 0</p>
                <p id="shippingCost" style="margin: 0; font-size: 0.9rem;">Rp. 0</p>
                <h5 id="totalPriceElementText" style="margin: 0; font-weight: bold; font-size: 1rem;" class="fw-bolder">
                    Rp. 0
                </h5>
            </div>
        </div>
            
       
            <!-- Submit Button -->
            <div class="text-center mt-3">
                  <button
                  type="submit"
                  class="btn-block d-flex justify-content-center align-items-center"  
                        style="background-color: #187444; 
                            color: #fff; 
                            padding: 0.75rem; 
                            font-size: 0.875rem; 
                            font-weight: bold; 
                            text-transform: uppercase; 
                            text-decoration: none; 
                            transition: all 0.3s ease-in-out; 
                            border-radius: 5px; 
                            border: 2px solid #0f8045; width: 100%;"
                        onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444';"
                        onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">
                    Ajukan Pengembalian
            </button>
            </div>
            </form>
        </div>
      </div>
    </main>

    <script>
document.addEventListener('DOMContentLoaded', function () {
    var endDate = document.getElementById('endDate');
    var totalLateDaysElementText = document.getElementById('totalLateDaysElementText');
    var totalLateDaysElementHidden = document.getElementById('totalLateDaysElementHidden');
    var lateFeeElement = document.getElementById('lateFeeElement');
    var damageFeeElement = document.getElementById('damageFeeElement');
    var shippingCostElement = document.getElementById('shippingCost');
    var shippingDescriptionHidden = document.getElementById('shippingDescriptionHidden');
    var totalPriceElementHidden = document.getElementById('totalPriceElementHidden');
    var totalPriceElementText = document.getElementById('totalPriceElementText');
    var ongkirSelect = document.getElementsByName('ongkir')[0];
    var productCards = document.getElementsByClassName('product-card');

    // Variabel tetap
    var fixedDamageFee = 0; // Biaya kerusakan (default 0)
    var shippingCost = 0; // Biaya ongkir awal
    var totalLateFee = 0; // Biaya keterlambatan awal

    // Fungsi untuk menghitung denda keterlambatan
    function calculateLateFee() {
        var today = new Date();
        var returnDate = new Date(endDate.value);
        var lateDays = 0;

        today.setHours(0, 0, 0, 0);
        returnDate.setHours(0, 0, 0, 0);

        // Jika ada keterlambatan
        if (today > returnDate) {
            var diffTime = today - returnDate;
            lateDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        } else {
            lateDays = 0;
        }

        // Reset totalLateFee sebelum menghitung
        totalLateFee = 0;

        // Hitung biaya keterlambatan untuk setiap produk
        Array.from(productCards).forEach(function (card) {
            var pricePerDay = parseInt(card.querySelector('.fw-bold span').textContent.replace(/[^0-9]/g, '')) || 0;
            var quantity = parseInt(card.querySelector('.card-text span').textContent) || 0;

            // Tambahkan ke total biaya keterlambatan
            totalLateFee += lateDays * pricePerDay * quantity;
        });

        // Update UI untuk keterlambatan
        totalLateDaysElementHidden.value = lateDays + ' hari';
        totalLateDaysElementText.textContent = lateDays + ' hari';
        lateFeeElement.textContent = 'Rp. ' + totalLateFee.toLocaleString('id-ID');
    }

    // Fungsi untuk menghitung total biaya
    function calculateTotalCost() {
        var total = totalLateFee + fixedDamageFee + shippingCost;

        // Update UI untuk total harga
        totalPriceElementHidden.value = isNaN(total) ? 0 : total;
        totalPriceElementText.textContent = 'Rp. ' + total.toLocaleString('id-ID');
    }

    // Event listener untuk perubahan ongkir
    ongkirSelect.addEventListener('change', function () {
        var selectedOption = ongkirSelect.options[ongkirSelect.selectedIndex];
        var description = selectedOption.dataset.name || ''; // Ambil deskripsi dari atribut data-name
        shippingCost = parseInt(selectedOption.dataset.cost) || 0; // Ambil biaya ongkir dari atribut data-cost

        // Update UI untuk ongkir
        shippingDescriptionHidden.value = description;
        shippingCostElementHidden.value = isNaN(shippingCost) ? 0 : shippingCost;
        shippingCostElement.textContent = 'Rp. ' + shippingCost.toLocaleString('id-ID');

        // Hitung ulang total biaya
        calculateTotalCost();
    });

    // Panggil fungsi perhitungan saat halaman dimuat
    calculateLateFee();
    calculateTotalCost();
});


    </script>