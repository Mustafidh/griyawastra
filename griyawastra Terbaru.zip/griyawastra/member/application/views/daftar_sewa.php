<main class="py-4">
    <div class="container" style="max-width: auto">
        <!-- Tabel Container -->
        <div class="table-responsive" style="background-color: #ffffff; padding: 30px; border-radius: 12px; box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);">
            <h2 style="text-align: center; font-weight: bold; margin-bottom: 20px; color: #333; font-size: 24px;">Penyewaan Anda</h2>
            <!-- Tabel -->
            <table class="table" style="border-collapse: separate; border-spacing: 0 12px;">
                <thead>
                    <tr style="background-color: #f0f0f0; border-radius: 10px;">
                        <th style="text-align: left; padding: 12px; font-weight: 600; color: #666;">No.</th>
                        <th style="text-align: left; padding: 12px; font-weight: 600; color: #666;">Kode Penyewaan</th>
                        <th style="text-align: center; padding: 12px; font-weight: 600; color: #666;">Tanggal Awal Sewa</th>
                        <th style="text-align: center; padding: 12px; font-weight: 600; color: #666;">Tanggal Kembali</th>
                        <th style="text-align: center; padding: 12px; font-weight: 600; color: #666;">Status</th>
                        <th style="text-align: right; padding: 12px; font-weight: 600; color: #666;">Total Harga</th>
                        <th style="text-align: center; padding: 12px; font-weight: 600; color: #666;">Opsi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!empty($penyewaan)) : ?>
                    <?php $no = 1; // Variabel penghitung untuk nomor urut ?>
                    <?php $no = $start_no; ?>
                    <?php foreach ($penyewaan as $row) : ?>
                        <tr style="background-color: #ffffff; box-shadow: 0 5px 10px rgba(0, 0, 0, 0.05); border-radius: 8px;">
                            <td style="padding: 16px; color: #333;"><?= $no++; ?></td> <!-- Menambahkan nomor urut -->
                            <td style="padding: 16px; color: #333;"><?= htmlspecialchars($row['kode_transaksi']); ?></td>
                            <td style="text-align: center; padding: 16px; color: #333;"><?php echo date('d-m-Y', strtotime($row['tgl_penyewaan'])); ?></td>
                            <td style="text-align: center; padding: 16px; color: #333;"><?php echo date('d-m-Y', strtotime($row['tgl_kembali'])); ?></td>
                            <td style="text-align: center; padding: 16px;">
                            <?php if ($row['status_penyewaan'] === 'Belum Bayar' || $row['status_penyewaan'] === 'Dibatalkan') : ?>
                                    <span class="badge" style="background-color: #AB3B3A; color: #fff;">Belum bayar</span>
                                <?php elseif ($row['status_penyewaan'] === 'Selesai') : ?>
                                    <span class="badge" style="background-color: #187444; color: #fff;">Selesai</span>
                                <?php elseif ($row['status_penyewaan'] === 'Proses Verifikasi') : ?>
                                    <span class="badge" style="background-color: #FFA500; color: #fff;">Proses Verifikasi</span>
                                <?php else : ?>
                                    <span class="badge" style="background-color: #00AA90; color: #fff;"><?= htmlspecialchars($row['status_penyewaan']); ?></span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: right; padding: 16px; color: #333;">Rp. <?= number_format($row['total_harga'], 0, ',', '.'); ?></td>
                            <td style="text-align: center; padding: 16px;">
                            <div style="display: flex; flex-wrap: wrap; gap: 2px; justify-content: center;">
                                <a class="mb-1"  
                                href="<?php echo site_url('penyewaan/detail/' . $row['id_penyewaan']); ?>" 
                                style="background-color: #187444; color: #fff; padding: 8px; font-size: 14px; font-weight: bold; text-decoration: none; transition: all 0.3s ease-in-out; border-radius: 8px; border: 2px solid #0f8045;"
                                onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444';"
                                onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">
                                Detail
                                </a>
                                <?php if ($row['status_penyewaan'] === 'Proses Verifikasi') : ?>
                                    <a class="mb-1"  
                                    href="<?php echo site_url('pengembalian/verifikasi/' . $row['id_penyewaan']); ?>" 
                                    style="background-color: #FFA500; color: #fff; padding: 8px; font-size: 14px; font-weight: bold; text-decoration: none; transition: all 0.3s ease-in-out; border-radius: 8px; border: 2px solid #FFA500;"
                                    onmouseover="this.style.backgroundColor='#fff'; this.style.color='#FFA500';"
                                    onmouseout="this.style.backgroundColor='#FFA500'; this.style.color='#fff';">
                                    Verifikasi
                                    </a>
                                <?php elseif ($row['status_penyewaan'] === 'Diverifikasi') : ?>
                                    <a class="mb-1"  
                                    href="<?php echo site_url('pengembalian/verifikasi/' . $row['id_penyewaan']); ?>" 
                                    style="background-color: #00AA90; color: #fff; padding: 8px; font-size: 14px; font-weight: bold; text-decoration: none; transition: all 0.3s ease-in-out; border-radius: 8px; border: 2px solid #00AA90;"
                                    onmouseover="this.style.backgroundColor='#fff'; this.style.color='#00AA90';"
                                    onmouseout="this.style.backgroundColor='#00AA90'; this.style.color='#fff';">
                                    Pembayaran
                                    </a>
                                <?php elseif ($row['status_penyewaan'] === 'Disewa') : ?>
                                    <a class="mb-1"  
                                    href="<?php echo site_url('penyewaan/pengembalian/' . $row['id_penyewaan']); ?>" 
                                    style="background-color: #00AA90; color: #fff; padding: 8px; font-size: 14px; font-weight: bold; text-decoration: none; transition: all 0.3s ease-in-out; border-radius: 8px; border: 2px solid #00AA90;"
                                    onmouseover="this.style.backgroundColor='#fff'; this.style.color='#00AA90';"
                                    onmouseout="this.style.backgroundColor='#00AA90'; this.style.color='#fff';">
                                    Pengembalian
                                    </a>
                                <?php elseif ($row['status_penyewaan'] === 'Selesai') : ?>
                                    <a class="mb-1"  
                                    href="<?php echo site_url('penyewaan/tampil_ulasan/' . $row['id_penyewaan']); ?>" 
                                    style="background-color: #00AA90; color: #fff; padding: 8px; font-size: 14px; font-weight: bold; text-decoration: none; transition: all 0.3s ease-in-out; border-radius: 8px; border: 2px solid #00AA90;"
                                    onmouseover="this.style.backgroundColor='#fff'; this.style.color='#00AA90';"
                                    onmouseout="this.style.backgroundColor='#00AA90'; this.style.color='#fff';">
                                    Rating
                                    </a>
                                <?php endif; ?>
                            </div>
                        </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 20px; color: #999;">Tidak ada data penyewaan.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
            
            <nav>
            <ul class="pagination justify-content-center">
                <?php if (!empty($pagination)) : ?>
                    <?= $pagination; ?> <!-- Menampilkan link pagination yang sudah dirancang di controller -->
                <?php else : ?>
                    <li class="page-item disabled">
                        <a class="page-link" href="#" style="color: #999; background-color: #f8f9fa; border: 1px solid #ddd; padding: 8px 8px; border-radius: 50px;">No Pages</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        </div>
    </div>
</main>
