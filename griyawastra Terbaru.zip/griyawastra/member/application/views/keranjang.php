<main>
  <div class="mt-5 mb-5 p-md-4 bg-white rounded shadow-sm" style="max-width: 800px; margin: 0 auto;">
    <h2 class="form-title text-center mb-4 mt-4" style="font-weight: bold; color: #333;">Keranjang</h2>
    <form action="<?= site_url('keranjang/lakukan_sewa'); ?>" method="post">
      <?php if (!empty($keranjang)) : ?>
        <?php foreach ($keranjang as $item) : ?>
          <div class="product-card d-flex justify-content-between align-items-center mb-2 p-3 border rounded shadow-sm">
            <div class="d-flex align-items-center">
              <!-- Kolom Checklist -->
              <div class="me-3">
                <input 
                  type="checkbox" 
                  name="selected_items[]" 
                  class="form-check-input select-item" 
                  style="width: 20px; height: 20px;" 
                  value="<?= $item->id_keranjang; ?>">
              </div>

              <!-- Gambar Produk dan Informasi -->
              <img src="<?= $this->config->item('url_uploads') . $item->foto_produk; ?>" alt="<?= $item->nama_produk; ?>" class="me-3" style="width: 80px; height: 80px; object-fit: cover;">
              
              <div class="product-info">
                <p class="mb-1" style="font-size: 16px;"><strong><?= $item->nama_produk; ?></strong></p>
                <p class="fw-bold mb-1 harga-k" style="font-size: 14px;">Harga/Hari: <span class="text-success">Rp. <?= number_format($item->harga_sewa, 0, ',', '.'); ?></span></p>

                <!-- Flexbox untuk Quantity dan Size -->
                <div class="d-flex justify-content-between" style="width: 225px;">
                  <!-- Quantity Selector (Kiri) -->
                  <div class="d-flex align-items-center" style="border: 1px solid #ced4da; border-radius: 25px; overflow: hidden; width: 100px;">
                    <button 
                      type="button" 
                      onclick="decrementQuantity(<?= $item->id_keranjang; ?>)" 
                      data-id_keranjang="quantity_<?= $item->id_keranjang; ?>" 
                      style="background: transparent; border: none; color: #187444; font-size: 18px; padding: 0px 10px; cursor: pointer; transition: color 0.3s;">
                      -
                    </button>
                    <input 
                      type="number" 
                      id="quantity_<?= $item->id_keranjang; ?>" 
                      class="form-control text-center" 
                      name="quantity[<?= $item->id_keranjang; ?>]"
                      min="1" 
                      value="<?= $item->jumlah; ?>" 
                      style="width: 50px; border: none; background-color: transparent; text-align: center; font-size: 16px; outline: none;">
                    <button 
                      type="button" 
                      onclick="incrementQuantity(<?= $item->id_keranjang; ?>)"  
                      style="background: transparent; border: none; color: #187444; font-size: 18px; padding: 0px 0px; cursor: pointer; transition: color 0.3s;">
                      +
                    </button>
                  </div>

                  <!-- Size Dropdown (Kanan) -->
                  <select 
                    class="form-select update-ukuran" 
                    name="size[<?= $item->id_keranjang; ?>]"
                    data-id_keranjang="<?= $item->id_keranjang; ?>"
                    style="width: 120px; border: 1px solid #ced4da; border-radius: 25px; background-color: transparent; padding: 5px 10px; font-size: 14px; color: #495057; appearance: none; outline: none; transition: all 0.3s ease;">
                    <option value="S" <?php echo ($item->ukuran === 'S') ? 'selected' : ''; ?>>S</option>
                    <option value="M" <?php echo ($item->ukuran === 'M') ? 'selected' : ''; ?>>M</option>
                    <option value="L" <?php echo ($item->ukuran === 'L') ? 'selected' : ''; ?>>L</option>
                    <option value="XL" <?php echo ($item->ukuran === 'XL') ? 'selected' : ''; ?>>XL</option>
                  </select>
                </div>
              </div>
            </div>

            <!-- Delete link -->
            <div class="delete-container">
              <a href="<?= site_url('keranjang/hapus/' . $item->id_keranjang); ?>" class="text-danger" style="font-size: 14px; text-decoration: none;" onclick="return confirm('Hapus produk ini?');">Hapus</a>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else : ?>
        <p class="text-center">Keranjang Anda kosong.</p>
      <?php endif; ?>

      <div class="p-1 mt-4">
        <div class="d-flex justify-content-between align-items-center">
          <a href="<?= base_url('welcome'); ?>" 
            class="" 
            style="background-color: #fff; 
                    color: #0f8045; 
                    padding: 0.75rem; 
                    font-size: 0.875rem; 
                    font-weight: bold; 
                    text-decoration: none; 
                    transition: all 0.3s ease-in-out; 
                    border-radius: 5px; 
                    border: 2px solid #0f8045;" 
            onmouseover="this.style.backgroundColor='#0f8045'; this.style.color='#fff';"
            onmouseout="this.style.backgroundColor='#fff'; this.style.color='#0f8045';">
            Lanjut Sewa Lainnya
          </a>

          <button
            type="submit"
            style="background-color: #187444; 
                    color: #fff; 
                    padding: 0.75rem; 
                    font-size: 0.875rem; 
                    font-weight: bold; 
                    text-decoration: none; 
                    transition: all 0.3s ease-in-out; 
                    border-radius: 5px;
                    border: 2px solid #0f8045;"
            onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444';"
            onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">
            Penyewaan
          </button>
        </div>
      </div>
    </form>
  </div>
</main>


<script>
  function decrementQuantity(id_keranjang) {
      var quantityInput = document.getElementById('quantity_' + id_keranjang);
      var quantity = parseInt(quantityInput.value);

      if (quantity > 1) {
          quantity--;
          quantityInput.value = quantity;
          
          updateJumlah(id_keranjang, quantity);
      }
  }

  function incrementQuantity(id_keranjang) {
      var quantityInput = document.getElementById('quantity_' + id_keranjang);
      var quantity = parseInt(quantityInput.value);
      quantity++;
      quantityInput.value = quantity;
      
      // Kirimkan update jumlah ke server
      updateJumlah(id_keranjang, quantity);
  }


  function updateJumlah(id_keranjang, jumlah) {
    $.ajax({
        url: '<?= site_url('keranjang/update_jumlah'); ?>', 
        type: 'POST',
        data: {
            id_keranjang: id_keranjang,
            jumlah: jumlah
        },
    });
  }

  function updateUkuran(id_keranjang, ukuran) {
    $.ajax({
        url: '<?= site_url('keranjang/update_ukuran'); ?>', 
        type: 'POST',
        data: {
            id_keranjang: id_keranjang,
            ukuran: ukuran
        },
    });
  }

  $(document).on('change', '.update-ukuran', function() {
    var id_keranjang = $(this).data('id_keranjang');
    var ukuran = $(this).val();
    updateUkuran(id_keranjang, ukuran); // Panggil fungsi updateUkuran
  });

  document.getElementById('btnPenyewaan').addEventListener('click', function () {
    let selectedItems = [];
    document.querySelectorAll('.select-item:checked').forEach(function (checkbox) {
        selectedItems.push(checkbox.getAttribute('data-id_keranjang'));
    });

    if (selectedItems.length > 0) {
        // Kirimkan data ke server menggunakan AJAX
        $.ajax({
            url: 'https://griyawastra.rf.gd/keranjang/proses_penyewaan',
            type: 'POST',
            data: { id_keranjang: selectedItems },
            success: function (response) {
                // Tampilkan respon atau lakukan tindakan lain
                alert('Penyewaan berhasil diproses!');
                window.location.href = 'https://griyawastra.rf.gd/penyewaan';
            },
            error: function (xhr, status, error) {
                alert('Terjadi kesalahan: ' + error);
            }
        });
    } else {
        alert('Pilih setidaknya satu item untuk disewa.');
    }
});
 
  </script>



