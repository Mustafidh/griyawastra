<div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
    <div style="display: flex; flex-wrap: wrap; max-width: 900px; width: 100%; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); border-radius: 10px; overflow: hidden; background-color: #ffffff;">
        <!-- Left Side -->
        <div style="flex: 1 1 50%; padding: 40px; background-color: #ffffff;">
            <h3 style="margin-bottom: 30px; font-weight: 700; color: #333; text-align: center;">Masuk</h3>
            <form action="<?= base_url('login/proses_login') ?>" method="POST">
            <div style="margin-bottom: 20px;">
                    <label for="email" style="display: block; margin-bottom: 5px; font-weight: bold;">Email</label>
                    <input type="email" id="email" name="email" value="<?php echo set_value('email'); ?>" placeholder="Masukkan email Anda" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; box-sizing: border-box;">
                    <span style="color: red; font-size: 14px;"><?php echo form_error('email'); ?></span>
                </div>

                <!-- Password Input -->
                <div style="margin-bottom: 10px;">
                    <label for="password" style="display: block; margin-bottom: 5px; font-weight: bold;">Kata Sandi</label>
                    <input type="password" id="password" name="password" value="<?php echo set_value('password'); ?>" placeholder="Masukkan kata sandi Anda" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; box-sizing: border-box;">
                    <span style="color: red; font-size: 14px;"><?php echo form_error('password'); ?></span>
                </div>
                <button type="submit" style="background-color: #187444;
                    width: 100%; 
                    padding: 10px;
                    color: #fff;
                    font-size: 0.875rem; 
                    font-weight: bold; 
                    text-transform: uppercase; 
                    text-decoration: none; 
                    transition: all 0.3s ease-in-out; 
                    border-radius: 5px;
                    border: 2px solid #187444;"
                    onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444'"
                    onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">Masuk</button>
            </form>
            <div style="text-align: center; margin-top: 20px;">
                <span style="display: inline-block; margin-bottom: 10px;">Atau Masuk Dengan</span><br>
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/768px-Google_%22G%22_logo.svg.png" alt="Google Login" style="width: 30px; height: 30px; cursor: pointer;">
            </div>
        </div>

        <!-- Right Side -->
        <div style="flex: 1 1 50%; display: flex; flex-direction: column; justify-content: center; align-items: center; background-image: url('<?= $this->config->item('url_gambar'); ?>login.jpg'); background-size: cover; background-position: right center; filter: brightness(1); padding: 40px; color: #fff;">
            <h3 style="margin-bottom: 20px; font-weight: 700;">Sugeng Rawuh!</h3>
            <p style="margin-bottom: 30px; text-align: center;">Belum punya akun? Daftar sekarang!</p>
            <a href="<?= base_url('register') ?>" style="background-color: #187444; 
                    padding: 10px 20px;
                    color: #fff;
                    font-size: 0.875rem; 
                    font-weight: bold; 
                    text-transform: uppercase; 
                    text-decoration: none; 
                    transition: all 0.3s ease-in-out; 
                    border-radius: 5px;
                    border: 2px solid #187444;"
                 onmouseover="this.style.backgroundColor='transparent'; this.style.color='#187444'"
                 onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">Daftar</a>
        </div>
    </div>
</div>
