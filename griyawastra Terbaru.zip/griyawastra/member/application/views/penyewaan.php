
<main>
      <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px;">
        <div class="mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 600px;">
          <h2 class="form-title mt-2">Penyewaan</h2>
        <form method="post" action="<?php echo site_url('penyewaan/simpan');?>" >
          <!-- Product Card -->
          <?php foreach ($keranjang as $item): ?>
          <div class="product-card mb-2">
          <img src="<?= $this->config->item('url_uploads') . $item['foto_produk']; ?>" alt="<?= $item->nama_produk; ?>" class="me-3" style="width: 80px; height: 80px; object-fit: cover;">
              <div class="product-info">
                  <p><strong><?php echo $item['nama_produk']; ?></strong></p>
                  <p class="card-text">Jumlah: <span class="text-success"><?php echo $item['jumlah']; ?></span></p>
                  <p class="card-text">Ukuran: <span class="text-success"><?php echo $item['ukuran']; ?></span></p>
                  <p class="card-text fw-bold">Harga/Hari: <span class="text-success">Rp. <?php echo number_format($item['harga_sewa']); ?></span></p>
                  <input type="hidden" name="id_produk[]" value="<?php echo $item['id_produk']; ?>"> <!-- Menyimpan ID produk ke dalam form -->
              </div>
          </div>
      <?php endforeach; ?>
            
            <!-- Rental Dates -->
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="startDate" class="form-label">Tanggal Awal Sewa</label>
                <input type="date" class="form-control" id="startDate" name="tgl_penyewaan" value="<?php echo set_value('tgl_penyewaan'); ?>" required>
              </div>
              <div class="col-md-6">
                <label for="endDate" class="form-label">Tanggal Kembali</label>
                <input type="date" class="form-control" id="endDate" name="tgl_kembali" value="<?php echo set_value('tgl_kembali'); ?>" required>
              </div>
            </div>
        
            <!-- Address -->
            <div class="mb-3">
                <label for="address" class="form-label">Alamat Penerima</label>
                <input type="text" class="form-control" id="address" value="<?php echo $pengguna['alamat'] . ', ' . $pengguna['nama_kab_pengguna']; ?>" readonly>
            </div>

        
            <!-- Courier -->
            <label for="ongkir" class="form-label">Opsi Pengiriman</label>
            <select class="form-control mb-3" name="ongkir" required>
            <option value="">Pilih</option>
            <?php foreach ($biaya['costs'] as $key => $value): ?>
                <option value="<?php echo $key ?>"
                        data-name="<?php echo $value['description']; ?>"
                        data-etd="<?php echo $value['cost'][0]['etd']; ?>"
                        data-cost="<?php echo $value['cost'][0]['value']; ?>">
                    <p>
                        <strong><?php echo $value['description']; ?></strong> |<br>
                        Rp. <?php echo number_format($value['cost'][0]['value'], 0, ',', '.'); ?> |<br>
                        <?php echo $value['cost'][0]['etd']; ?> Hari
                    </p>
                </option>
            <?php endforeach ?>
        </select>
        
            <!-- Payment Details -->
            <div class="total-payment bg-light p-3 rounded border d-flex justify-content-between align-items-center">
            <div class="left-info">
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Durasi Sewa</p>
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Ongkir</p>
                <p style="margin: 0; font-weight: bold; font-size: 1rem;" class="fw-bolder">Total</p>
            </div>
            <div class="right-info text-end">
                <input type="hidden" name="durasi_sewa" id="rentalDurationHidden" value="">
                <input type="hidden" name="total_harga" id="totalPriceHidden" value="">
                <input type="hidden" name="biaya_ekspedisi" id="shippingCostHidden" value="">
                <input type="hidden" name="nama_ekspedisi" id="shippingDescriptionHidden" value="">
                <input type="hidden" name="estimasi_ekspedisi" id="shippingEtdHidden" value="">

                <p id="rentalDurationText" value="" style="margin: 0; font-size: 0.9rem;">0</p>
                <p id="shippingCost" style="margin: 0; font-size: 0.9rem;">Rp. 0</p>
                <h5 id="totalPriceText" style="margin: 0; font-weight: bold; font-size: 1rem;" class="fw-bolder">Rp. 0</h5>
            </div>
        </div>
            
       
            <!-- Submit Button -->
            <div class="text-center mt-3">
                <button id="pay-button" 
                        class="submit btn-block" 
                        style="background-color: #187444; 
                            color: #fff; 
                            padding: 0.75rem; 
                            font-size: 0.875rem; 
                            font-weight: bold; 
                            text-transform: uppercase; 
                            text-decoration: none; 
                            transition: all 0.3s ease-in-out; 
                            border-radius: 5px; 
                            border: 2px solid #0f8045; width: 100%;"
                        onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444';"
                        onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">
                    Sewa Sekarang!
                </button>
            </div>

        </form>
        </div>
      </div>
    </main>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
    var startDate = document.getElementById('startDate');
    var endDate = document.getElementById('endDate');
    var rentalDurationHidden = document.getElementById('rentalDurationHidden');
    var rentalDurationText = document.getElementById('rentalDurationText');
    var totalPriceHidden = document.getElementById('totalPriceHidden');
    var totalPriceText = document.getElementById('totalPriceText');
    var shippingCostElement = document.getElementById('shippingCost'); // Elemen biaya ongkir
    var ongkirSelect = document.querySelector('[name="ongkir"]'); // Dropdown ongkir
    var shippingCost = 0; // Biaya pengiriman awal
    var shippingEtdHidden = document.getElementById('shippingEtdHidden');

    function calculateRental() {
        var start = new Date(startDate.value);
        var end = new Date(endDate.value);

        if (start && end) {
            var diffTime = Math.abs(end - start);
            var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

            rentalDurationHidden.value = isNaN(diffDays) ? '...' : diffDays + ' hari';
            rentalDurationText.textContent = isNaN(diffDays) ? '...' : diffDays + ' hari'; 

            // Ambil harga per hari dari produk
            var total = 0;
            <?php foreach ($keranjang as $item): ?>
            var hargaProduk = <?php echo json_encode($item['harga_sewa']); ?>;
            var jumlahProduk = <?php echo $item['jumlah']; ?>;

            total += isNaN(diffDays * hargaProduk * jumlahProduk) ? '...' : diffDays * hargaProduk * jumlahProduk;
            <?php endforeach; ?>

            // Tambahkan biaya pengiriman
            total += shippingCost;

            // Tampilkan hasil
            totalPriceHidden.value = isNaN(total) ? 0 : total;
            totalPriceText.textContent = 'Rp. ' + (isNaN(total) ? '...' : total.toLocaleString());
        } else {
            rentalDurationHidden.value = '0 hari';
            rentalDurationText.textContent = '0 hari';
            totalPriceHidden.value = 'Rp. 0';
            totalPriceText.textContent = 'Rp. 0';
        }

        // Tampilkan biaya ongkir
        shippingCostElement.textContent = 'Rp. ' + (isNaN(shippingCost) ? '...' : shippingCost.toLocaleString());
        shippingCostHidden.value = isNaN(shippingCost) ? 0 : shippingCost; // Tetap integer
    }

    // Event listener untuk dropdown ongkir
    ongkirSelect.addEventListener('change', function () {
        var selectedOption = ongkirSelect.options[ongkirSelect.selectedIndex];
        var description = selectedOption.dataset.name; // Ambil deskripsi
        var value = parseInt(selectedOption.dataset.cost) || 0; 
        var etd = selectedOption.dataset.etd || '';// Ambil nilai biaya

        shippingCost = value;
        shippingEtdHidden.value = etd;
        shippingCostHidden.value = shippingCost;
        shippingDescriptionHidden.value = description;
        calculateRental(); // Update total harga
    });

    // Validasi tanggal untuk mencegah pemilihan tanggal kembali sebelum tanggal sewa
    endDate.addEventListener('change', function () {
        var start = new Date(startDate.value);
        var end = new Date(endDate.value);

        if (end < start) {
            endDate.value = ''; // Clear endDate if invalid
        }

        calculateRental(); // Recalculate total
    });

    // Event listener untuk tanggal
    startDate.addEventListener('change', calculateRental);

    
});
</script>