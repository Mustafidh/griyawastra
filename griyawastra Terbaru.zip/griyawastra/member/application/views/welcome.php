<div id="carouselExampleDark" class="carousel carousel-dark slide">
  
<div id="carouselExampleDark" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <?php foreach ($slider as $key => $value): ?>
    <div class="carousel-item <?php echo $key == '0' ? 'active' : ''; ?>">
      <img src="<?php echo $this->config->item('url_slider').$value['foto_slider']; ?>" class="d-block w-100" style="max-height: 600px; object-fit: cover;">
      <div class="overlay" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5);"></div>
        <div class="carousel-caption d-none d-md-block">
          <h5 class="text-white fw-bold"><?php echo $value['caption_slider']; ?></h5>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>


<section class="bg-white py-5">
  <div class="container">
    <h5 class="text-center mb-5">Kategori Produk</h5>
    <div class="row">
      <?php foreach ($kategori as $key => $value): ?>
      <div class="col-md-4 text-center mb-4" >
        <a href="<?php echo base_url("kategori/detail/".$value["id_kategori"]) ?>" class="text-decoration-none">
        <img src="<?php echo $this->config->item("url_kategori").$value["foto_kategori"] ?>" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
        <h5 style="color: #333;" class="mt-3"><?php echo $value['nama_kategori'] ?></h5>
        </a>
      </div>
      <?php endforeach ?>
    </div>
  </div>
</section>


<section class="bg-light py-5">
  <div class="container">
    <h5 class="text-center mb-5">Produk Terbaru</h5>
    <div class="row">
      <?php foreach ($produk as $key => $value): ?>
      <div class="col-md-3 mb-4">
        <a href="<?php echo base_url("produk/detail/".$value["id_produk"]) ?>" class="text-decoration-none">
          <div class="card h-100 border-0 shadow-sm">
            <img src="<?php echo $this->config->item("url_produk").$value["foto_produk"] ?>" class="card-img-top" alt="<?php echo $value['nama_produk'] ?>" style="height: 300px; object-fit: cover;">
            <div class="card-body text-center d-flex flex-column" style="color: #333;">
              <h6 class="card-title"><?php echo $value['nama_produk'] ?></h6>
              <span class="mt-auto">Rp. <?php echo number_format($value['harga_produk']) ?></span>
            </div>
          </div>
        </a>
      </div>
      <?php endforeach ?>
    </div>
  </div>
</section>


<section class="bg-white py-5">
  <div class="container">
    <h5 class="text-center mb-5">Artikel Produk</h5>
    <div class="row">
      <?php foreach ($artikel as $key => $value): ?>
      <div class="col-md-3 text-center mb-4">
        <div class="card h-100 border-0 shadow-sm">
          <img src="<?php echo $this->config->item("url_artikel").$value["foto_artikel"] ?>" class="card-img-top" style="height: 200px; object-fit: cover;">
          <div class="card-body">
            <h6 class="card-title mt-3"><?php echo $value['judul_artikel'] ?></h6>
          </div>
        </div>
      </div>
      <?php endforeach ?>
    </div>
  </div>
</section>
