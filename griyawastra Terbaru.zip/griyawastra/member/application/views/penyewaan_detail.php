
<main>
      <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px;">
        <div class="mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 600px;">
          <h2 class="form-title mt-2">Detail Penyewaan</h2>
          <!-- Product Card -->
            <?php foreach ($produk as $item): ?>
                <div class="product-card mb-2">
                <img src="<?= $this->config->item('url_uploads') . $item['foto_produk']; ?>" alt="<?= $item['nama_sewa']; ?>" class="me-3" style="width: 80px; height: 80px; object-fit: cover;">
                    <div class="product-info">
                        <p><strong><?php echo $item['nama_produk']; ?></strong></p>
                        <p class="card-text">Jumlah: <span class="text-success"><?php echo $item['jumlah_sewa']; ?></span></p>
                        <p class="card-text">Ukuran: <span class="text-success"><?php echo $item['ukuran_sewa']; ?></span></p>
                        <p class="card-text fw-bold">Harga/Hari: <span class="text-success">Rp. <?php echo number_format($item['harga_satuan']); ?></span></p>
                        <input type="hidden" name="id_produk[]" value="<?php echo $item['id_produk']; ?>"> <!-- Menyimpan ID produk ke dalam form -->
                    </div>
                </div>
            <?php endforeach; ?>
            
            <!-- Rental Dates -->
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="startDate" class="form-label">Tanggal Awal Sewa</label>
                <input type="date" class="form-control" id="startDate" name="tgl_penyewaan" 
                value="<?php echo isset($penyewaan['tgl_penyewaan']) ? date('Y-m-d', strtotime($penyewaan['tgl_penyewaan'])) : ''; ?>" readonly>
              </div>
              <div class="col-md-6">
                <label for="endDate" class="form-label">Tanggal Kembali</label>
                <input type="date" class="form-control" id="endDate" name="tgl_kembali" 
                value="<?php echo isset($penyewaan['tgl_kembali']) ? date('Y-m-d', strtotime($penyewaan['tgl_kembali'])) : ''; ?>" readonly>
              </div>
            </div>
        
            <!-- Address -->
            <div class="mb-3">
                <label for="address" class="form-label">Alamat Penerima</label>
                <input type="text" class="form-control" id="address" value="<?php echo $pengguna['alamat'] . ', ' . $pengguna['nama_kab_pengguna']; ?>" readonly>
            </div>

        
            <!-- Courier -->
            <div class="mb-3">
                <label for="address" class="form-label">Jasa Pengiriman</label>
                <input type="text" class="form-control" id="address" value="<?php echo $penyewaan['layanan_ekspedisi'].' | '. $penyewaan['nama_ekspedisi'] . ' | ' . $penyewaan['estimasi_ekspedisi']; ?> Hari" readonly>
            </div>
            
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <input type="text" class="form-control" id="address" value="<?php echo $penyewaan['status_penyewaan']; ?>" readonly>
            </div>
                
            <div class="mb-3">
                <label for="address" class="form-label">Resi Pengiriman</label>
                <input type="text" class="form-control" id="address" value="<?php echo $penyewaan['resi_ekspedisi']; ?>" readonly>
            </div>

            <!-- Payment Details -->
            <div class="total-payment bg-light p-3 rounded border d-flex justify-content-between align-items-center">
            <div class="left-info">
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Durasi Sewa</p>
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Ongkir</p>
                <p style="margin: 0; font-weight: bold; font-size: 1rem;" class="fw-bolder">Total</p>
            </div>
            <div class="right-info text-end">
                <p style="margin: 0; font-size: 0.9rem;"><?php echo $penyewaan['durasi_sewa']; ?></p>
                <p style="margin: 0; font-size: 0.9rem;">Rp. <?php echo number_format($penyewaan['biaya_ekspedisi']); ?></p>
                <h5 style="margin: 0; font-weight: bold; font-size: 1rem;" class="fw-bolder">
                    Rp. <?php echo number_format($penyewaan['total_harga'], 0, ',', '.'); ?>
                </h5>
            </div>
        </div>
            
       
            <!-- Submit Button -->
            <div class="text-center mt-3">
                  <a
                  href="<?php echo site_url('penyewaan/daftar_sewa'); ?>"
                  class="btn-block d-flex justify-content-center align-items-center"  
                        style="background-color: #187444; 
                            color: #fff; 
                            padding: 0.75rem; 
                            font-size: 0.875rem; 
                            font-weight: bold; 
                            text-transform: uppercase; 
                            text-decoration: none; 
                            transition: all 0.3s ease-in-out; 
                            border-radius: 5px; 
                            border: 2px solid #0f8045; width: 100%;"
                        onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444';"
                        onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">
                    Penyewaan Anda
                  </a>
            </div>
        </div>
      </div>
    </main>

    <?php if (!empty($snapToken)): ?>
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-u5GHOXbiy0ra2bnI"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        snap.pay('<?php echo $snapToken?>', {
          onSuccess: function(result){
            location.reload();
          },
          onPending: function(result){
          },
          onError: function(result){
          }
        });
      });
    </script>
<?php endif ?>
