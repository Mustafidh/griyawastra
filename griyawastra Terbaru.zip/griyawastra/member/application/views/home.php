 <!-- Header -->
 <div class="container px-4 px-lg-5 mt-2">
    <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active" data-bs-interval="10000">
                <img class="d-block w-100" src="<?= $this->config->item('url_gambar'); ?>b.jpg" alt="frog" style="height: 550px; object-fit: cover;" />
            </div>
            <div class="carousel-item" data-bs-interval="2000">
                <img class="d-block w-100" src="<?= $this->config->item('url_gambar'); ?>a.jpg" alt="frog" style="height: 550px; object-fit: cover; object-position: 50% 100%;" />
            </div>
            <div class="carousel-item">
                <img class="d-block w-100" src="<?= $this->config->item('url_gambar'); ?>c.jpg" alt="frog" style="height: 550px; object-fit: cover; object-position: 50% 80%;" />
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</div>

    <!-- Section-->
<!-- Section Produk -->
<section class="py-5 text-center">
    <h4 class="text-center text-primary fw-bold">Produk Kami</h4>
    <div class="container px-4 px-lg-5 mt-5">
        <div class="row gx-2 gx-lg-5 row-cols-1 row-cols-md-3 justify-content-center">
            <?php foreach ($produk as $product): ?>
            <div class="col mb-5">
                <div class="card h-100">
                    <!-- Gambar Produk -->
                    <img class="card-img-top" src="<?= $this->config->item('url_uploads'); ?><?= $product['foto_produk']; ?>" alt="" style="width: 100%; height: auto; object-fit: cover; max-height: 250px;"/>
                    <div class="card-body p-4">
                        <!-- Nama Produk -->
                        <div class="text-center">
                            <div class="badge bg-primary mb-2 text-white"><?= htmlspecialchars($product['nama_kategori']); ?></div>
                            <h6 class="fw-bolder"><?= htmlspecialchars($product['nama_produk']); ?></h6>
                            <!-- Harga -->
                            <h5 class="fw-bold mt-2">Rp. <?= number_format($product['harga_sewa'], 0, ',', '.'); ?><span> /Hari</span></h5>
                        </div>
                    </div>
                    <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                        <div class="text-center">
                            <a class="btn btn-outline-dark mt-auto fw-bold" style="
                                font-size: 0.875rem; 
                                padding: 0.375rem 0.75rem; 
                                border: 1px solid #187444; 
                                color: #187444; 
                                transition: all 0.3s ease-in-out; 
                                display: inline-block; 
                                text-decoration: none;
                                text-align: center;" 
                                onmouseover="this.style.backgroundColor='#187444'; this.style.color='white';" 
                                onmouseout="this.style.backgroundColor='transparent'; this.style.color='#187444';" 
                                href="<?= base_url('produk/detail/' . $product['id_produk']); ?>">Lihat Produk</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

    
    <!-- Category Section -->
<section class="py-5 text-center">
    <h4 class="text-center text-primary fw-bold">Kategori Busana</h4>
    <div class="container mt-5 ">
    <div class="row justify-content-center">
    <?php foreach ($kategori as $category): ?>
        <div class="col-md-2">
            <!-- Gambar dengan ukuran 100x100 dan bentuk lingkaran -->
            <img src="<?= $this->config->item('url_kategori'); ?><?= $category['foto_kategori']; ?>" 
                 class="rounded-circle" 
                 alt="<?= htmlspecialchars($category['nama_kategori']); ?>" 
                 style="width: 100px; height: 100px; object-fit: cover;" />
            <p class="mt-2 fw-bold"><?= htmlspecialchars($category['nama_kategori']); ?></p>
        </div>
    <?php endforeach; ?>
    </div>

    </div>
</section>


