
<main>
      <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px;">
        <div class="mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 600px;">
          <h2 class="form-title mt-2">Verifikasi Pengembalian</h2>
          <form action="<?php echo site_url('pengembalian/verifikasi'); ?>" method="post" enctype="multipart/form-data">
          <!-- Product Card -->
          <?php foreach ($produk as $item): ?>
                <div class="product-card mb-2">
                <img src="<?= $this->config->item('url_uploads') . $item['foto_produk']; ?>" alt="<?= $item['nama_sewa']; ?>" class="me-3" style="width: 80px; height: 80px; object-fit: cover;">
                    <div class="product-info">
                        <p><strong><?php echo $item['nama_produk']; ?></strong></p>
                        <p class="card-text">Jumlah: <span class="text-success"><?php echo $item['jumlah_sewa']; ?></span></p>
                        <p class="card-text">Ukuran: <span class="text-success"><?php echo $item['ukuran_sewa']; ?></span></p>
                        <p class="card-text fw-bold">Harga/Hari: <span class="text-success">Rp. <?php echo number_format($item['harga_satuan']); ?></span></p>
                        <input type="hidden" name="id_produk[]" value="<?php echo $item['id_produk']; ?>"> <!-- Menyimpan ID produk ke dalam form -->
                    </div>
                </div>
            <?php endforeach; ?>
            
            <!-- Rental Dates -->
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="startDate" class="form-label" style="font-weight: 500;">Tanggal Awal Sewa</label>
                <input type="date" class="form-control" id="startDate" name="tgl_penyewaan" 
                value="<?php echo isset($penyewaan['tgl_penyewaan']) ? date('Y-m-d', strtotime($penyewaan['tgl_penyewaan'])) : ''; ?>" readonly>
              </div>
              <div class="col-md-6">
                <label for="endDate" class="form-label" style="font-weight: 500;">Tanggal Kembali</label>
                <input type="date" class="form-control" id="endDate" name="tgl_kembali" 
                value="<?php echo isset($penyewaan['tgl_kembali']) ? date('Y-m-d', strtotime($penyewaan['tgl_kembali'])) : ''; ?>" readonly>
              </div>
            </div>
            
            <div class="mb-3">
                <label for="address" class="form-label" style="font-weight: 500;">Alamat Toko Kami</label>
                <input type="text" class="form-control" id="address" value="Tunjungbiru, Wilutama, Gondokusuman, Yogyakarta 51362" readonly>
            </div>

            <!-- Address -->
            <div class="mb-3">
                <label for="address" class="form-label" style="font-weight: 500;">Alamat Pengguna</label>
                <input type="text" class="form-control" id="address" value="<?php echo $pengguna['alamat'] . ', ' . $pengguna['nama_kab_pengguna']; ?>" readonly>
            </div>

            <!-- Courier -->
            <div class="mb-3">
                <label for="address" class="form-label" style="font-weight: 500;">Jasa Pengiriman</label>
                <input type="text" class="form-control" id="address" value="<?php echo $penyewaan['nama_ekspedisi'] . ' | ' . $penyewaan['estimasi_ekspedisi']; ?> Hari" readonly>
            </div>
            
            <div class="mb-3">
                <label for="status" class="form-label" style="font-weight: 500;">Status</label>
                <input type="text" class="form-control" id="address" value="<?php echo $penyewaan['status_penyewaan']; ?>" readonly>
            </div>

            <!-- Payment Details -->
            <div class="total-payment bg-light p-3 rounded border d-flex justify-content-between align-items-center">
            <div class="left-info">
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Keterlambatan</p>
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Kerusakan</p>
              <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Ongkir</p>
                <p id="totalPriceElement" style="margin: 0; font-weight: bold; font-size: 1rem;" class="fw-bolder">Total Pengembalian</p>
            </div>
            <div class="right-info text-end">
            <input type="hidden" name="id_penyewaan" value="<?php echo $penyewaan['id_penyewaan']; ?>">

                <p style="margin: 0; font-size: 0.9rem;"><?php echo $pengembalian['hari_terlewat']; ?></p>
                <p style="margin: 0; font-size: 0.9rem;">Rp. <?php echo number_format($pengembalian['denda_kerusakan']); ?></p>
                <p style="margin: 0; font-size: 0.9rem;">Rp. <?php echo number_format($pengembalian['biaya_ekspedisi']); ?></p>
                <h5 id="totalPengembalian" style="margin: 0; font-weight: bold; font-size: 1rem;" class="fw-bolder">
                    Rp. <?php echo number_format($pengembalian['total_pengembalian']); ?>
                </h5>
            </div>
        </div>
            
        <?php if ($penyewaan['status_penyewaan'] === 'Diverifikasi'): ?>
          <!-- Submit Button -->
          <div class="text-center mt-3">
            <button type="submit" id="paymentButton"
                    class="btn-block d-flex justify-content-center align-items-center"
                    style="background-color: #187444; color: #fff; padding: 0.75rem; font-size: 0.875rem; font-weight: bold; text-transform: uppercase; text-decoration: none; transition: all 0.3s ease-in-out; border-radius: 5px; border: 2px solid #0f8045; width: 100%;"
                    onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444';"
                    onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">
              Pembayaran Pengembalian
            </button>
          </div>
        <?php else: ?>
            <div class="text-center mt-3">
                    <button type="submit"
                        class="btn-block d-flex justify-content-center align-items-center" disabled
                        style="background-color: #187444; color: #fff; padding: 0.75rem; font-size: 0.875rem; font-weight: bold; text-transform: uppercase; text-decoration: none; transition: all 0.3s ease-in-out; border-radius: 5px; border: 2px solid #0f8045; width: 100%; pointer-events: none; filter: grayscale(50%);"
                        onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444';"
                        onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">
                        Pembayaran Pengembalian
                    </button>
                </div>
        <?php endif; ?>
            </form>
        </div>
      </div>
    </main>

    <?php if (!empty($snapToken)): ?>
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-u5GHOXbiy0ra2bnI"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        snap.pay('<?php echo $snapToken?>', {
          onSuccess: function(result){
            location.reload();
          },
          onPending: function(result){
          },
          onError: function(result){
          }
        });
      });
    </script>
<?php endif ?>



    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Ambil elemen-elemen yang dibutuhkan
        const dendaKerusakan = parseFloat(<?php echo json_encode($pengembalian['denda_kerusakan']); ?>);
        const totalPengembalianElement = document.getElementById('totalPengembalian');

        // Ambil nilai total_pengembalian dari PHP
        let totalPengembalian = parseFloat(<?php echo json_encode($pengembalian['total_pengembalian']); ?>);

        // Tambahkan denda_kerusakan ke total_pengembalian
        totalPengembalian += dendaKerusakan;

        // Perbarui tampilan total_pengembalian di HTML
        totalPengembalianElement.textContent = 'Rp. ' + new Intl.NumberFormat('id-ID').format(totalPengembalian);
    });
</script>


