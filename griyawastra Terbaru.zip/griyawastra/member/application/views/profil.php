<main>
    <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; border-radius: 15px;">
        <div class="mt-5 mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 600px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <h2 class="form-title mt-2 text-center" style="font-weight: bold; font-size: 1.5rem;">Profil Pengguna</h2>

            <form action="<?= site_url('profil') ?>" method="post">
    <!-- Nama Pengguna -->
              <div class="mb-3">
                  <label for="username" class="form-label" style="font-weight: 500;">Nama Pengguna</label>
                  <input type="text" class="form-control" id="username" name="username" value="<?= set_value('username', $username); ?>" placeholder="Masukkan Nama Pengguna" style="border-radius: 5px; border: 1px solid #ddd;">
                  <?= form_error('username', '<div class="text-danger">', '</div>'); ?>
              </div>

              <!-- Email -->
              <div class="mb-3">
                  <label for="email" class="form-label" style="font-weight: 500;">Email</label>
                  <input type="email" class="form-control" id="email" name="email" value="<?= set_value('email', $email); ?>" placeholder="Masukkan Email" style="border-radius: 5px; border: 1px solid #ddd;">
                  <?= form_error('email', '<div class="text-danger">', '</div>'); ?>
              </div>

              <div class="mb-3">
                  <label for="password" class="form-label" style="font-weight: 500;">Password</label>
                  <input type="password" class="form-control" id="password" name="password" value="" placeholder="Ubah Password" style="border-radius: 5px; border: 1px solid #ddd;">
              </div>


              <!-- Alamat -->
              <div class="mb-3">
                  <label for="address" class="form-label" style="font-weight: 500;">Alamat</label>
                  <input type="text" class="form-control" id="address" name="address" value="<?= set_value('address', $alamat); ?>" placeholder="Masukkan Alamat Lengkap" style="border-radius: 5px; border: 1px solid #ddd;">
                  <?= form_error('address', '<div class="text-danger">', '</div>'); ?>
              </div>

              <!-- No. Telepon -->
              <div class="mb-3">
                  <label for="phone" class="form-label" style="font-weight: 500;">No. Telepon</label>
                  <input type="text" class="form-control" id="phone" name="phone" value="<?= set_value('phone', $phone); ?>" placeholder="Masukkan No. Telepon" style="border-radius: 5px; border: 1px solid #ddd;">
                  <?= form_error('phone', '<div class="text-danger">', '</div>'); ?>
              </div>

              <!-- No. KTP -->
              <div class="mb-3">
                  <label for="ktp" class="form-label" style="font-weight: 500;">No. KTP</label>
                  <input type="text" class="form-control" id="ktp" name="ktp" value="<?= set_value('ktp', $ktp); ?>" placeholder="Masukkan No. KTP" style="border-radius: 5px; border: 1px solid #ddd;">
                  <?= form_error('ktp', '<div class="text-danger">', '</div>'); ?>
              </div>

              <!-- Kabupaten/Provinsi -->
              <div class="mb-3">
              <label for="province" class="form-label" style="font-weight: 500;">Kabupaten/Provinsi</label>
              <select id="province" name="province" class="form-select" style="border-radius: 5px; border: 1px solid #ddd;">
                  <!-- Opsi default jika belum dipilih -->
                  <option value="">Pilih Kabupaten/Provinsi</option>
                  
                  <?php
                  // Debugging: Cek nilai province_code
                  echo '<!-- Debugging: province_code = ' . $province_code . ' -->';

                  foreach ($distrik as $d) {
                      // Tentukan apakah ini yang dipilih berdasarkan province_code
                      $selected = ($d['city_id'] == $province_code) ? 'selected' : ''; 
                      echo '<option value="' . $d['city_id'] . '" ' . $selected . '>' . $d['city_name'] . '</option>';
                  }
                  ?>
              </select>
              <?= form_error('province', '<div class="text-danger">', '</div>'); ?>
          </div>


              <!-- Tombol Simpan -->
              <div class="text-center mt-4">
                  <button type="submit" class="btn w-100" style="background-color: #187444; color: #fff; padding: 0.75rem; font-size: 1rem; font-weight: bold; text-transform: uppercase; text-decoration: none; transition: all 0.3s ease-in-out; border-radius: 5px; border: 2px solid #0f8045;">
                      Simpan
                  </button>
              </div>
          </form>

        </div>
    </div>
</main>
