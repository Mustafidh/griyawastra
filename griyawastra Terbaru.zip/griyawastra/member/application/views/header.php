<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Griya Wastra</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
<!-- Include Toastr JS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <!-- Core theme CSS (includes Bootstrap)-->
    <link rel="stylesheet" type="text/css" href="<?= $this->config->item('url_css'); ?>styles.css?v=<?= time(); ?>">
</head>
<body class="cover">

<!-- Navigation-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container px-4 px-lg-5">
    <a class="navbar-brand text-primary fw-bolder" href="<?= base_url('welcome'); ?>">Griya Wastra</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <!-- Navbar Links -->
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
    <li class="nav-item">
        <a class="nav-link text-primary fs-6 hover-primary" aria-current="page" href="<?= base_url('welcome'); ?>" style="font-size: 1rem; padding: 0.5rem 1rem;">Beranda</a>
    </li>
    <li class="nav-item">
        <a class="nav-link text-primary fs-6 hover-primary" href="<?= base_url('produk'); ?>" style="font-size: 1rem; padding: 0.5rem 1rem;">Produk</a>
    </li>
    <li class="nav-item">
        <a class="nav-link text-primary fs-9 hover-primary" href="#!" style="font-size: 1rem; padding: 0.5rem 1rem;">Syarat & Ketentuan</a>
    </li>
    <li class="nav-item">
        <a class="nav-link text-primary fs-9 hover-primary" href="#!" style="font-size: 1rem; padding: 0.5rem 1rem;">Tentang Kami</a>
    </li>
    <!-- Cek apakah pengguna sudah login -->
    <?php if ($this->session->userdata('logged_in')): ?>
        <li class="nav-item">
            <a class="nav-link text-primary fs-6 hover-primary" href="<?= site_url('penyewaan/daftar_sewa'); ?>" style="font-size: 1rem; padding: 0.5rem 1rem;">Penyewaan</a>
        </li>
    <?php endif; ?>
</ul>

</ul>
      
      <!-- Search Form -->
      <form class="d-flex me-3 mb-2 mb-lg-0" action="<?= base_url('produk'); ?>" method="get">
        <div class="input-group" 
             style="max-width: 500px; width: 100%; border-radius: 50px; overflow: hidden; position: relative; border: 1px solid #187444;">
          
          <!-- Search Icon (Decorative on the Left) -->
          
          <!-- Input Field -->
          <input 
            class="form-control form-control-sm" 
            type="search" 
            placeholder="Cari produk..." 
            aria-label="Search" 
            name="query" 
            style="font-size: 0.875rem; border: none; border-radius: 50px; padding-left: 40px; outline: none; box-shadow: none;">
          
          <!-- Submit Button -->
          <button 
            class="btn btn-sm" 
            type="submit" 
            style="position: absolute; right: 0; top: 0; bottom: 0; font-size: 0.875rem; background-color: #fff; border: none; padding: 0.375rem 1rem; border-top-left-radius: 0; border-bottom-left-radius: 0; transition: all 0.3s ease-in-out;">
            <i class="bi bi-search" style="font-size: 1rem; color: #187444;"></i>
          </button>
        </div>
      </form>
      
      <!-- Cart and Profile Buttons -->
      <!-- Keranjang Button -->
          <?php if ($this->session->userdata('logged_in')): ?>
              <a
                  href="<?= base_url('keranjang'); ?>"
                  class="btn btn-sm mb-2 mb-lg-0" 
                  type="button" 
                  style="
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    width: 45px;
                    height: 45px;
                    color: #187444;
                  "
              >
                  <i 
                      class="bi bi-cart-fill" 
                      style="font-size: 1.5rem;"
                  ></i>
              </a>
          <?php endif; ?>

          <!-- Profile Button -->
          <?php if ($this->session->userdata('logged_in')): ?>
              <a 
                  href="<?php echo site_url('profil'); ?>" 
                  class="btn btn-sm me-2 mb-2 mb-lg-0" 
                  style="
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    width: 45px;
                    height: 45px;
                    color: #187444;
                  "
              >
                  <i 
                      class="bi bi-person" 
                      style="font-size: 1.5rem;"
                  ></i>
              </a>
          <?php endif; ?>

          
                  <!-- Cek apakah pengguna sudah login -->
          <?php if ($this->session->userdata('logged_in')): ?>
              <!-- Tombol Logout -->
              <a href="<?= base_url('login/logout'); ?>" class="btn btn-outline-danger fw-bold btn-sm mb-2 mb-lg-0" style="font-size: 0.875rem; padding: 0.375rem 0.75rem; border: 1px solid #d9534f; color: #d9534f; transition: all 0.3s ease-in-out;" onmouseover="this.style.backgroundColor='#d9534f'; this.style.color='white';"
               onmouseout="this.style.backgroundColor='transparent'; this.style.color='#d9534f';">
                  Keluar
              </a>
          <?php else: ?>
              <!-- Tombol Login -->
              <a href="<?= base_url('login'); ?>" class="btn btn-outline-primary fw-bold btn-sm mb-2 mb-lg-0" style="font-size: 0.875rem; padding: 0.375rem 0.75rem; border: 1px solid #187444; color: #187444; transition: all 0.3s ease-in-out;" onmouseover="this.style.backgroundColor='#187444'; this.style.color='white';"
              onmouseout="this.style.backgroundColor='transparent'; this.style.color='#187444';">
                  Masuk
              </a>
          <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
