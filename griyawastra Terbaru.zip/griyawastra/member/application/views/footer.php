<!-- Footer -->
<footer class="bg-white py-4">
  <div class="container px-5">
    <div class="row align-items-center">
      
      <!-- Brand Name -->
      <div class="col-12 col-md-4 mb-3 mb-md-0">
        <h4 class="fw-bold" style="color: #187444;">Griya Wastra</h4>
      </div>
      
      <!-- Navigation Links -->
      <div class="col-12 col-md-4 text-center mb-3 mb-md-0">
        <a href="<?= base_url('welcome'); ?>" class="text-decoration-none me-3" style="color: #187444; font-weight: bold;" onmouseover="this.style.color='#27965c';" onmouseout="this.style.color='#187444';">Beranda</a>
        <a href="resume.html" class="text-decoration-none me-3" style="color: #187444; font-weight: bold;" onmouseover="this.style.color='#27965c';" onmouseout="this.style.color='#187444';">Produk</a>
        <a href="projects.html" class="text-decoration-none me-3" style="color: #187444; font-weight: bold;" onmouseover="this.style.color='#27965c';" onmouseout="this.style.color='#187444';">Syarat & Ketentuan</a>
        <a href="contact.html" class="text-decoration-none" style="color: #187444; font-weight: bold;" onmouseover="this.style.color='#27965c';" onmouseout="this.style.color='#187444';">Tentang Kami</a>
      </div>
      
      <!-- Address and Contact -->
      <div class="col-12 col-md-4 text-md-end">
        <p class="mb-1" style="font-size: 14px;">Tunjungbiru, Wilutama, Gondokusuman<br>Yogyakarta 51362</p>
          <!-- Instagram Icon -->
          <i class="bi bi-instagram" style="font-size: 18px; color: #187444; margin-left: 15px; cursor: pointer;"></i>
          
          <!-- Facebook Icon -->
          <i class="bi bi-facebook" style="font-size: 18px; color: #187444; margin-left: 15px; cursor: pointer;"></i>
          
          <!-- WhatsApp Icon -->
          <i class="bi bi-whatsapp" style="font-size: 18px; color: #187444; margin-left: 15px; cursor: pointer;"></i>
        </p>
        
        <div class="col-auto">
          <div class="small m-0">Copyright &copy; Griya Wastra 2025</div>
        </div>
      </div>

    </div>
  </div>
</footer>


    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- footer.php -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php if ($this->session->flashdata('pesan_sukses')): ?>
    <script>swal("Berhasil!", "<?php echo $this->session->flashdata('pesan_sukses'); ?>", "success");</script>
    <?php endif ?>

    <?php if ($this->session->flashdata('pesan_gagal')): ?>
    <script>swal("Gagal!", "<?php echo $this->session->flashdata('pesan_gagal'); ?>", "error");</script>
    <?php endif ?>
</body>
</html>