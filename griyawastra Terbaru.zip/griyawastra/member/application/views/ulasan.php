<main>
  <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px;">
    <div class="mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 800px; border: 1px solid #ddd;">
      <h2 class="form-title mt-2" style="font-size: 1.5rem; font-weight: bold; text-align: center;">Beri Penilaian</h2>
      <form method="post" action="<?php echo site_url('penyewaan/ulasan'); ?>">
        <!-- Loop untuk setiap produk -->
        <?php foreach ($produk as $item): ?>
          <div class="product-card mb-4 p-3" style="border: 1px solid #ddd; border-radius: 5px;">
            <!-- Info Produk -->
            <div style="display: flex; align-items: center; margin-bottom: 10px;">
              <img src="<?= $this->config->item('url_uploads') . $item['foto_produk']; ?>" alt="<?= $item['nama_produk']; ?>" style="width: 80px; height: 80px; object-fit: cover; border-radius: 5px; margin-right: 15px;">
              <div  class="me-md-4" style="flex: 1;">
                <p style="margin: 0; font-size: 1rem; font-weight: bold;"><?= $item['nama_produk']; ?></p>
                <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Jumlah: <?= $item['jumlah_sewa']; ?></p>
                <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Ukuran: <?= $item['ukuran_sewa']; ?></p>
                <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">Harga/Hari: Rp. <?= number_format($item['harga_satuan']); ?>
                <input type="hidden" name="id_produk[]" value="<?= $item['id_produk']; ?>"></p>
              </div>
            </div>

            <!-- Rating -->
            <div class="rating mb-3 me-md-4">
              <label for="rating_<?= $item['id_produk']; ?>" style="display: block; margin-bottom: 5px; font-weight: bold;">Rating</label>
              <div class="stars" data-id="<?= $item['id_produk']; ?>" style="display: flex; gap: 5px; font-size: 1.5rem;">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                  <input type="radio" name="rating[<?= $item['id_produk']; ?>]" value="<?= $i; ?>" id="star<?= $i; ?>_<?= $item['id_produk']; ?>" required style="display: none;">
                  <label for="star<?= $i; ?>_<?= $item['id_produk']; ?>" 
                        data-value="<?= $i; ?>" 
                        class="star" 
                        style="cursor: pointer; color: gray;">★</label>
                <?php endfor; ?>
              </div>
            </div>

            <!-- Ulasan -->
            <div class="ulasan mb-3">
              <label for="review_<?= $item['id_produk']; ?>" style="display: block; margin-bottom: 5px; font-weight: bold;">Ulasan Anda</label>
              <textarea id="review_<?= $item['id_produk']; ?>" name="ulasan[<?= $item['id_produk']; ?>]" rows="3" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;" placeholder="Tulis ulasan Anda untuk produk ini..." required></textarea>
            </div>
          </div>
        <?php endforeach; ?>

        <!-- Tombol Submit -->
        <div class="text-center mt-3">
          <button type="submit" 
                  style="background-color: #187444; 
                         color: #fff; 
                         padding: 0.75rem; 
                         font-size: 0.875rem; 
                         font-weight: bold; 
                         text-transform: uppercase; 
                         text-decoration: none; 
                         transition: all 0.3s ease-in-out; 
                         border-radius: 5px; 
                         border: 2px solid #0f8045; 
                         width: 100%;"
                  onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444';"
                  onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">
            Kirim Penilaian
          </button>
        </div>
      </form>
    </div>
  </div>
</main>

<script>
  document.querySelectorAll('.stars').forEach(starContainer => {
    const stars = starContainer.querySelectorAll('.star');
    stars.forEach(star => {
      star.addEventListener('click', () => {
        const value = star.dataset.value;

        // Reset all stars to gray
        stars.forEach(s => s.style.color = 'gray');

        // Highlight clicked star and all previous stars
        stars.forEach(s => {
          if (s.dataset.value <= value) {
            s.style.color = '#ffd700'; // Yellow
          }
        });
      });
    });
  });
</script>

