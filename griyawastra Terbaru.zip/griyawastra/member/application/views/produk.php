<section class="py-5 text-center">
    <h4 class="text-center text-primary fw-bold">Produk Kami</h4>
    <div class="container px-4 px-lg-5 mt-5">
        <div class="row gx-2 gx-lg-5 row-cols-1 row-cols-md-3 justify-content-center">
            <?php foreach ($produk as $product): ?>
            <div class="col mb-5">
                <div class="card h-100">
                    <!-- Gambar Produk -->
                    <img class="card-img-top" src="<?= $this->config->item('url_uploads'); ?><?= $product['foto_produk']; ?>" alt="" style="width: 100%; height: auto; object-fit: cover; max-height: 250px;"/>
                    <div class="card-body p-4">
                        <!-- Nama Produk -->
                        <div class="text-center">
                            <div class="badge bg-primary mb-2 text-white"><?php 
                            foreach ($kategori as $k) {
                                if ($k['id_kategori'] == $product['id_kategori']) {
                                    echo $k['nama_kategori'];
                                    break;
                                }
                            }
                             ?></div>
                            <h6 class="fw-bolder"><?= htmlspecialchars($product['nama_produk']); ?></h6>
                            <!-- Harga -->
                            <h5 class="fw-bold mt-2">Rp. <?= number_format($product['harga_sewa'], 0, ',', '.'); ?><span> /Hari</span></h5>
                        </div>
                    </div>
                    <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                        <div class="text-center">
                            <a class="btn btn-outline-dark mt-auto fw-bold" style="
                                font-size: 0.875rem; 
                                padding: 0.375rem 0.75rem; 
                                border: 1px solid #187444; 
                                color: #187444; 
                                transition: all 0.3s ease-in-out; 
                                display: inline-block; 
                                text-decoration: none;
                                text-align: center;" 
                                onmouseover="this.style.backgroundColor='#187444'; this.style.color='white';" 
                                onmouseout="this.style.backgroundColor='transparent'; this.style.color='#187444';" 
                                href="<?= base_url('produk/detail/' . $product['id_produk']); ?>">Lihat Produk</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <nav style="margin-top: 20px;">
            <ul class="pagination justify-content-center" style="gap: 10px;">
                <?php if (!empty($pagination)) : ?>
                    <?= $pagination; ?> <!-- Menampilkan link pagination yang sudah dirancang di controller -->
                <?php else : ?>
                    <li class="page-item disabled">
                        <a class="page-link" href="#" style="color: #999; background-color: #f8f9fa; border: 1px solid #ddd; padding: 8px 16px; border-radius: 50px;">No Pages</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</section>