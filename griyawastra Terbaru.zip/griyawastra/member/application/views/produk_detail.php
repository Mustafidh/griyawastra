<div class="container mt-5">
    <div class="row">
        <!-- Carousel Section -->
        <div class="col-md-6">
            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"></li>
                    <?php foreach ($gambar_tambahan as $index => $gambar): ?>
                        <li data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?= $index + 1; ?>"></li>
                    <?php endforeach; ?>
                </ol>
                <!-- Carousel Items -->
                <div class="carousel-inner">
                    <!-- Gambar Utama (foto_produk) -->
                    <div class="carousel-item active">
                        <img src="<?= $this->config->item('url_uploads') . $produk['foto_produk']; ?>" 
                             class="d-block w-100 img-preview" 
                             alt="Gambar Utama" 
                             style="width: 100%; height: auto; object-fit: cover; max-height: 400px;" 
                             data-bs-toggle="modal" data-bs-target="#imagePreviewModal">
                    </div>
                    <!-- Gambar Tambahan -->
                    <?php foreach ($gambar_tambahan as $index => $gambar): ?>
                        <div class="carousel-item">
                            <img src="<?= $this->config->item('url_uploads') . $gambar['nama_gambar']; ?>" 
                                 class="d-block w-100 img-preview" 
                                 alt="Gambar Tambahan <?= $index + 1; ?>" 
                                 style="width: 100%; height: auto; object-fit: cover; max-height: 400px;" 
                                 data-bs-toggle="modal" data-bs-target="#imagePreviewModal">
                        </div>
                    <?php endforeach; ?>
                </div>
                <!-- Navigation Controls -->
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </a>
            </div>
        </div>

<!-- Modal untuk Preview Gambar -->
<div class="modal fade" id="imagePreviewModal" tabindex="-1" aria-labelledby="imagePreviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center fw-bold" id="imagePreviewModalLabel">Preview Gambar</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <img id="modalImage" src="" alt="Preview Gambar" style="width: 100%; height: auto; object-fit: contain;">
            </div>
        </div>
    </div>
</div>

            <div class="col-md-6">
    <div class="badge bg-primary mb-2 text-white"><?= htmlspecialchars($produk['nama_kategori']); ?></div>
    <h1 class="mb-3"><?= htmlspecialchars($produk['nama_produk']); ?></h1>
    <h3 class="mt-2 fw-bold">Rp <?= number_format($produk['harga_sewa'], 0, ',', '.'); ?> <span> /Hari</span></h3>
    <p class="text-muted small mb-3"><?= htmlspecialchars($produk['berat_produk']); ?>g</p>
    <div style="max-height: 150px; overflow-y: auto;">
        <p><?= nl2br(htmlspecialchars($produk['deskripsi_produk'])); ?></p>
    </div>

    <!-- Form untuk mengirim data ke keranjang -->
    <form method="post" action="<?= base_url('keranjang/tambah'); ?>">
        <input type="hidden" name="id_produk" value="<?= htmlspecialchars($produk['id_produk']); ?>">
        <input type="hidden" name="harga_sewa" value="<?= htmlspecialchars($produk['harga_sewa']); ?>">

        <!-- Quantity Input and Size Selector -->
        <div class="d-flex align-items-center mt-3" style="gap: 15px;">


        <button 
            id="sewaBtn" 
            class="btn bg-primary fw-bold btn-sm" 
            style="
                font-size: 18px; 
                padding: 5px 20px; 
                border-radius: 8px; 
                color: #fff; 
                border: none; 
                text-decoration: none; 
                text-align: center; 
                transition: background-color 0.3s ease;
            ">
            Sewa!
        </button>

    <!-- Quantity Input -->
    <div class="d-flex align-items-center" style="gap: 10px;">
        <div class="d-flex align-items-center" style="border: 1px solid #ced4da; border-radius: 25px; overflow: hidden;">
            <button 
                type="button" 
                onclick="decrementQuantity()"
                style="background: transparent; border: none; color: #187444; font-size: 16px; padding: 0 20px; cursor: pointer; transition: color 0.3s;">
                -
            </button>
            <input 
                type="number" 
                id="quantity" 
                name="jumlah" 
                class="form-control text-center" 
                min="1" 
                value="1" 
                max="<?= $produk['stok']; ?>"
                style="width: 60px; border: none; background-color: transparent; text-align: center; font-size: 16px; outline: none;">
            <button 
                type="button" 
                onclick="incrementQuantity()" 
                style="background: transparent; border: none; color: #187444; font-size: 16px; padding: 0 20px; cursor: pointer; transition: color 0.3s;">
                +
            </button>
        </div>

        <!-- Size Dropdown -->
       <!-- Size Dropdown -->
                <select 
                    class="form-select" 
                    id="sizeSelect" 
                    name="ukuran" 
                    required 
                    aria-label="Pilih ukuran baju"
                    style="width: 60px; border: 1px solid #ced4da; border-radius: 25px; background-color: transparent; padding: 5px 10px; font-size: 16px; color: #495057; appearance: none; -webkit-appearance: none; -moz-appearance: none; outline: none; transition: all 0.3s ease;">
                    <option value="S">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                </select>
    </div>

    <!-- Submit Button -->
    
</div>
</div>
           
<section>
    <div class="mt-5">
        <h4 class="mb-4 fw-bolder" style="font-size: 1.5rem; font-weight: 500;">Ulasan dan Rating</h4>
        <div class="row">
            <!-- Rating Section -->
            <div class="col-md-6">
                <h5 style="font-size: 1.2rem; font-weight: 600;">Rating Produk</h5>
                <div style="background: rgba(128, 128, 128, 0.1); backdrop-filter: blur(10px); padding: 20px; border-radius: 15px; border: 1px solid rgba(255, 255, 255, 0.1);">
                    <?php if ($total_reviews > 0): ?>
                        <i class="bi bi-star-fill" style="color: #ffd700; font-size: 1.5rem;"></i>
                        <span style="font-size: 1.2rem; font-weight: 600;"><?php echo number_format($avg_rating, 1); ?></span>
                        <p class="small text-muted" style="font-size: 0.9rem; margin-top: 10px;"><?php echo $total_reviews; ?> Ulasan</p>
                    <?php else: ?>
                        <p class="text-muted">Belum ada rating untuk produk ini.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Reviews Section -->
            <div class="col-md-6">
                <h5 style="font-size: 1.2rem; font-weight: 600;">Ulasan Pelanggan</h5>
                <?php if ($total_reviews > 0): ?>
                    <?php foreach ($reviews as $review): ?>
                        <div class="mb-3" style="background: rgba(128, 128, 128, 0.1); backdrop-filter: blur(10px); padding: 20px; border-radius: 15px; border: 1px solid rgba(255, 255, 255, 0.3);">
                            <strong style="font-weight: 600;"><?php echo $review->nama_pengguna; ?></strong>
                            <div>
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <?php echo ($i <= $review->rating) ? '★' : '☆'; ?>
                                <?php endfor; ?>
                            </div>
                            <p class="review-text" style="font-size: 0.9rem;"><?php echo htmlspecialchars($review->komentar); ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div style="background: rgba(128, 128, 128, 0.1); padding: 20px; border-radius: 15px; border: 1px solid rgba(255, 255, 255, 0.3);">
                        <p class="text-muted">Belum ada komentar untuk produk ini.</p>
                    </div>
                <?php endif; ?>
                <?php if ($total_reviews > 3): ?>
                <div style="text-align: right; margin-top: 15px;">
                    <a href="#more-reviews" style="color: #187444; font-size: 1rem; font-weight: 600; text-decoration: none; cursor: pointer;" onmouseover="this.style.color='#27965c';" onmouseout="this.style.color='#187444';">
                        Lihat Komentar Lainnya
                    </a>
                </div>
            <?php endif; ?>
            </div>
        </div>
    </div>
</section>
</div>


     
        
        
   <section class="py-5 text-center">
    <h4 class="text-center text-primary fw-bold">Produk Lainnya</h4>
    <div class="container px-4 px-lg-5 mt-5">
        <div class="row gx-2 gx-lg-5 row-cols-1 row-cols-md-3 justify-content-center">
            <?php foreach ($recommended_produk as $item): ?>
                <div class="col mb-5">
                <div class="card h-100">
                        <?php 
                        // Cek jika ada gambar produk yang valid
                        $foto_produk = isset($item['foto_produk']) ? $item['foto_produk'] : 'default-image.png';
                        ?>
                        <img src="<?= $this->config->item('url_uploads'); ?><?= $item['produk']['foto_produk'] ?>" class="card-img-top" alt="<?= htmlspecialchars($item['produk']['nama_produk']); ?>" style="height: 300px; object-fit: cover;">
                        <div class="card-body p-4">
                            <div class="badge bg-primary mb-2 text-white"><?= htmlspecialchars($item['produk']['nama_kategori']); ?></div>
                            <div class="text-center">
                                <h6 class="fw-bold"><?= htmlspecialchars($item['produk']['nama_produk']); ?></h6>
                                <h5 class="fw-bold mt-2">Rp. <?= number_format($item['produk']['harga_sewa'], 0, ',', '.'); ?><span> /Hari</span></h5>
                            </div>
                        </div>
                        <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                            <div class="text-center">
                                <a class="btn btn-outline-dark mt-auto fw-bold" style="
                                font-size: 0.875rem; 
                                padding: 0.375rem 0.75rem; 
                                border: 1px solid #187444; 
                                color: #187444; 
                                transition: all 0.3s ease-in-out; 
                                display: inline-block; 
                                text-decoration: none;
                                text-align: center;" 
                                onmouseover="this.style.backgroundColor='#187444'; this.style.color='white';" 
                                onmouseout="this.style.backgroundColor='transparent'; this.style.color='#187444';" 
                                href="<?= site_url('produk/detail/' . $item['produk']['id_produk']); ?>">Lihat Produk</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
</div>

    <script>
    // Fungsi untuk mengurangi jumlah
    function decrementQuantity() {
        const quantityInput = document.getElementById('quantity');
        let currentValue = parseInt(quantityInput.value);
        if (currentValue > 1) { // Batas minimum adalah 1
            quantityInput.value = currentValue - 1;
        }
    }

    // Fungsi untuk menambah jumlah
    function incrementQuantity() {
        const quantityInput = document.getElementById('quantity');
        let currentValue = parseInt(quantityInput.value);
        quantityInput.value = currentValue + 1;
    }

    document.getElementById('sewaBtn').addEventListener('click', function(event) {
        <?php if (!$this->session->userdata('logged_in') || !$this->session->userdata('profil_lengkap')): ?>
            event.preventDefault();
            Swal.fire({
            });
      <?php endif; ?>

        <?php if (!$this->session->userdata('logged_in')): ?>
            // Jika pengguna belum login
            Swal.fire({
                icon: 'warning',
                title: 'Belum Login!',
                text: 'Silakan login terlebih dahulu untuk menyewa baju.',
                showConfirmButton: true,
                confirmButtonText: 'Login Sekarang',
                customClass: {
                        confirmButton: 'swal2-confirm'
    }
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "<?= site_url('login'); ?>"; // Redirect ke halaman login
                }
            });
        <?php elseif (!$this->session->userdata('profil_lengkap')): ?>
            // Jika profil pengguna belum lengkap
            Swal.fire({
                icon: 'info',
                title: 'Profil Tidak Lengkap!',
                text: 'Silakan lengkapi profil Anda terlebih dahulu.',
                showConfirmButton: true,
                confirmButtonText: 'Lengkapi Profil',
                customClass: {
                        confirmButton: 'swal2-confirm'
    }
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "<?= site_url('profil'); ?>"; // Redirect ke halaman profil
                }
            });
        <?php endif; ?>
    });

</script>

<script>
    document.querySelectorAll('.img-preview').forEach(img => {
        img.addEventListener('click', function () {
            const modalImage = document.getElementById('modalImage');
            modalImage.src = this.src;
        });
    });
</script>