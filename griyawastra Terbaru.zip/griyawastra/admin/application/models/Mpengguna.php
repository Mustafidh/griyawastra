<?php
class Mpengguna extends CI_Model {
    function tampil(){
        $q = $this->db->get("pengguna");

        $d = $q->result_array();

        return $d;

    }
    function detail($id_pengguna){
        $this->db->where('id_pengguna', $id_pengguna);
        $q = $this->db->get("pengguna");

        $d = $q->row_array();
        return $d;
    }

    public function hapus($id_pengguna)
    {
        // Menghapus data dari tabel 'pengguna' berdasarkan id_pengguna
        $this->db->where('id_pengguna', $id_pengguna);
        return $this->db->delete('pengguna'); // Return true jika berhasil, false jika gagal
    }
}