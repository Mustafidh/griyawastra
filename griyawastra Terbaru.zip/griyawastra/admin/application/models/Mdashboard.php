<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdashboard extends CI_Model {

    public function get_total_produk() {
        return $this->db->count_all('produk');
    }

    public function get_total_pengguna() {
        return $this->db->count_all('pengguna');
    }

    public function get_total_penyewaan() {
        return $this->db->count_all('penyewaan');
    }
}
