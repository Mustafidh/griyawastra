<?php
class Mproduk extends CI_Model {
    function tampil(){
        $q = $this->db->get("produk");

        $d = $q->result_array();

        return $d;

    }
    

    function detail($id_produk){
        $this->db->where('id_produk', $id_produk);
        $q = $this->db->get("produk");

        $d = $q->row_array();
        return $d;
    }

    function simpan($inputan)
{
    // Konfigurasi upload
    $config['upload_path'] = $this->config->item("assets_uploads");
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    $config['file_name'] = uniqid(); // Nama file unik

    $this->load->library('upload', $config);

    // Upload gambar utama
    $ngupload = $this->upload->do_upload("foto_produk");
    if ($ngupload) {
        $inputan['foto_produk'] = $this->upload->data("file_name");
    }

    // Insert data produk
    $this->db->insert('produk', $inputan);

    // Mengembalikan ID produk yang baru saja disimpan
    return $this->db->insert_id();
}

public function hapus($id_produk)
    {
        // Menghapus data dari tabel 'produk' berdasarkan id_produk
        $this->db->where('id_produk', $id_produk);
        return $this->db->delete('produk'); // Return true jika berhasil, false jika gagal
    }

public function simpan_gambar_tambahan($gambar_tambahan)
{
    // Insert batch data gambar tambahan ke tabel gambar_produk
    $this->db->insert_batch('gambar_produk', $gambar_tambahan);
}

public function get_gambar_tambahan($id_produk)
{
    $this->db->where('id_produk', $id_produk);
    return $this->db->get('gambar_produk')->result_array();
}


function edit($inputan, $id_produk)
{
    // Konfigurasi upload
    $config['upload_path'] = $this->config->item("assets_uploads");
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    $config['file_name'] = uniqid(); // Nama file unik

    $this->load->library('upload', $config);

    // Upload gambar utama (jika ada)
    $ngupload = $this->upload->do_upload("foto_produk");
    if ($ngupload) {
        $inputan['foto_produk'] = $this->upload->data("file_name");
    }

    // Update data produk
    $this->db->where('id_produk', $id_produk);
    $this->db->update('produk', $inputan);
}


    public function get_kategori()
    {
        return $this->db->get('kategori')->result_array();
    }
}