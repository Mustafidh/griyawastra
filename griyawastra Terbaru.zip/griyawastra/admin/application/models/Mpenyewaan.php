<?php
class Mpenyewaan extends CI_Model {
    function tampil(){
        $this->db->select('penyewaan.*, pengguna.nama_pengguna AS nama_pengguna');
    $this->db->from('penyewaan'); // Pastikan hanya satu FROM untuk tabel penyewaan
    $this->db->join('pengguna', 'penyewaan.id_pengguna = pengguna.id_pengguna'); // JOIN untuk relasi
    $query = $this->db->get();
    return $query->result_array();
    }

    function detail($id_penyewaan){
        $this->db->where('id_penyewaan', $id_penyewaan);
        $q = $this->db->get("penyewaan");

        $d = $q->row_array();
        return $d;

    }
    public function update_penyewaan($id_penyewaan, $data) {
        $this->db->where('id_penyewaan', $id_penyewaan);
        return $this->db->update('penyewaan', $data);
    }
        public function getDetailPenyewaan($id_penyewaan) {
            $this->db->select('penyewaan.*, pengguna.nama_pengguna as nama_pengguna, pengguna.email_pengguna as email_pengguna');
            $this->db->from('penyewaan');
            $this->db->join('pengguna', 'pengguna.id_pengguna = penyewaan.id_pengguna'); // Relasi antar tabel
            $this->db->where('penyewaan.id_penyewaan', $id_penyewaan); // Filter berdasarkan ID penyewaan
            return $this->db->get()->row_array(); // Ambil satu baris data
        }

        public function get_pengembalian_by_id_penyewaan($id_penyewaan)
    {
        $this->db->select('penyewaan.id_penyewaan, penyewaan.kode_transaksi, penyewaan.status_penyewaan, pengembalian.kode_pengembalian, pengembalian.hari_terlewat, pengembalian.denda_kerusakan, pengembalian.gambar_kondisi, pengembalian.nama_ekspedisi, pengembalian.biaya_ekspedisi, pengembalian.total_pengembalian');
        $this->db->from('pengembalian');
        $this->db->join('penyewaan', 'penyewaan.id_penyewaan = pengembalian.id_penyewaan', 'left');
        $this->db->where('penyewaan.id_penyewaan', $id_penyewaan);
        $query = $this->db->get();
        return $query->row_array(); // Mengembalikan satu baris hasil query
    }

        public function get_penyewaan_with_pengembalian($id_penyewaan) {
            $this->db->select('penyewaan.*, pengembalian.*');
            $this->db->from('penyewaan');
            $this->db->join('pengembalian', 'penyewaan.id_penyewaan = pengembalian.id_penyewaan', 'left');
            $this->db->where('penyewaan.id_penyewaan', $id_penyewaan);
            return $this->db->get()->row_array();
        }


        public function update_pengembalian($id_penyewaan, $data)
        {
            $this->db->where('id_penyewaan', $id_penyewaan);
            return $this->db->update('pengembalian', $data);
        }
    
        public function update_status_penyewaan($id_penyewaan, $data)
        {
            $this->db->where('id_penyewaan', $id_penyewaan);
            return $this->db->update('penyewaan', $data);
        }
}