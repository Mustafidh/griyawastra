<div class="app-wrapper">
        <div class="app-content pt-3 p-md-3 p-lg-4">
		    <div class="container-xl">
			    
			    <div class="row g-3 mb-4 align-items-center justify-content-between">
				    <div class="col-auto">
			            <h1 class="app-page-title mb-0">Tambah Produk</h1>
				    </div>
				    <div class="col-auto">
					     <div class="page-utilities">
						    <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							    <div class="col-auto">
								    <form class="table-search-form row gx-1 align-items-center">
					                    <div class="col-auto">
					                        <input type="text" id="search-orders" name="searchorders" class="form-control search-orders" placeholder="Search">
					                    </div>
					                    <div class="col-auto">
					                        <button type="submit" class="btn app-btn-secondary">Search</button>
					                    </div>
					                </form>
					                
							    </div><!--//col-->
						    </div><!--//row-->
					    </div><!--//table-utilities-->
				    </div><!--//col-auto-->
			    </div><!--//row-->

        <main>
            <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; border-radius: 15px;">
              <div class="mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 600px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                <h2 class="form-title mt-2 mb-4 text-center" style="font-weight: bold; font-size: 1.5rem;">Tambah Produk</h2>
                <form action="<?php echo base_url('inventaris/tambah'); ?>" method="post" enctype="multipart/form-data">
                  <!-- Nama Pengguna -->
                  <div class="mb-3">
                    <label for="username" class="form-label" style="font-weight: 500;">Nama Produk</label>
                    <input type="text" class="form-control" placeholder="Masukkan Nama Produk" style="border-radius: 5px; border: 1px solid #ddd;" name="nama_produk" value="<?php echo set_value("nama_produk")?>">
                    <span class="text-danger">
                        <?php echo form_error("nama_produk");?>
                    </span>
                  </div>
          
                  <!-- Email -->
                  <div class="mb-3">
                    <label for="email" class="form-label" style="font-weight: 500;">Harga/Hari</label>
                    <input type="text" class="form-control" id="email" placeholder="Masukkan Harga/Hari" style="border-radius: 5px; border: 1px solid #ddd;" name="harga_sewa" value="<?php echo set_value("harga_sewa");?>">
                    <span class="text-danger">
                        <?php echo form_error("harga_sewa");?>
                    </span>
                  </div>
                   

                  <!-- Password -->
                  <div class="mb-3">
                    <label for="password" class="form-label" style="font-weight: 500;">Berat</label>
                    <input type="text" class="form-control" id="password" placeholder="Masukkan Berat" style="border-radius: 5px; border: 1px solid #ddd;" name="berat_produk" value="<?php echo set_value("berat_produk");?>">
                    <span class="text-danger">
                        <?php echo form_error("berat_produk");?>
                    </span>
                  </div>
                   

                  <!-- Kab/Provinsi -->
                  <div class="mb-3">
                        <label for="kategori" class="form-label" style="font-weight: 500;">Kategori</label>
                        <select id="kategori" class="form-select" name="id_kategori" style="border-radius: 5px; border: 1px solid #ddd;">
                            <option selected>Pilih Kategori</option>
                            <?php foreach ($kategori as $row): ?>
                                <option value="<?php echo $row['id_kategori']; ?>">
                                    <?php echo $row['nama_kategori']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>


                  <!-- Password -->
                  <div class="mb-3">
                    <label for="password" class="form-label" style="font-weight: 500;">Stok</label>
                    <input type="text" class="form-control" id="password" placeholder="Masukkan Stok" style="border-radius: 5px; border: 1px solid #ddd;" name="stok" value="<?php echo set_value("stok");?>">
                    <span class="text-danger">
                        <?php echo form_error("stok");?>
                    </span>
                  </div>
                  

				  <div class="mb-3">
					<label for="deskripsi" class="form-label" style="font-weight: 500;">Deskripsi</label>
					<textarea class="form-control" id="deskripsi" name="deskripsi_produk" placeholder="Masukkan Deskripsi" style="border-radius: 5px; border: 1px solid #ddd; height: 100px;"></textarea>
				</div>
				
				<div class="mb-3">
					<label for="gambar" class="form-label" style="font-weight: 500;">Gambar Utama</label>
					<input type="file" class="form-control" name="foto_produk" value="" placeholder="Pilih Gambar" style="border-radius: 5px; border: 1px solid #ddd;" required>
				</div>

        <div class="mb-3">
					<label for="gambar2" class="form-label" style="font-weight: 500;">Gambar Lainnya</label>
					<input type="file" class="form-control" name="gambar_tambahan[]" value="" placeholder="Pilih Gambar" style="border-radius: 5px; border: 1px solid #ddd;" multiple>
				</div>
				
                  
                  <!-- Tombol Simpan -->
                  <div class="text-center mt-4">
                    <button type="submit"
                       class="btn w-100"
                       style="background-color: #187444; 
                              color: #fff; 
                              padding: 0.75rem; 
                              font-size: 1rem; 
                              font-weight: bold; 
                              text-transform: uppercase; 
                              text-decoration: none; 
                              transition: all 0.3s ease-in-out; 
                              border-radius: 5px;
                              border: 2px solid #0f8045;"
                       onmouseover="this.style.backgroundColor='#fff'; this.style.color='#187444';"
                       onmouseout="this.style.backgroundColor='#187444'; this.style.color='#fff';">
                      Tambah
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </main>
    
    </div><!--//app-wrapper-->    				