<div class="app-wrapper">
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">
            <div class="row g-3 mb-4 align-items-center justify-content-between">
                <div class="col-auto">
                    <h1 class="app-page-title mb-0">Pengguna Detail</h1>
                </div>
                <div class="col-auto">
                    <div class="page-utilities">
                        <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
                            <div class="col-auto">
                                <form class="table-search-form row gx-1 align-items-center">
                                    <div class="col-auto">
                                        <input type="text" id="search-orders" name="searchorders" class="form-control search-orders" placeholder="Search">
                                    </div>
                                    <div class="col-auto">
                                        <button type="submit" class="btn app-btn-secondary">Search</button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-auto">                            
                                <a class="btn app-btn-secondary" href="#">Keluar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <main>
                <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; border-radius: 15px;">
                    <div class="mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 600px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                        <h2 class="form-title mt-2 mb-4 text-center" style="font-weight: bold; font-size: 1.5rem;">Detail Pengguna</h2>
                            <!-- Nama pengguna -->
                            <div class="mb-3">
                                <label for="nama_pengguna" class="form-label" style="font-weight: 500;">Nama pengguna</label>
                                <input type="text" class="form-control" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="nama_pengguna" value="<?= set_value('nama_pengguna', $pengguna['nama_pengguna']); ?>" readonly>
                            </div>
                            
                            <!-- Harga/Hari -->
                            <div class="mb-3">
                                <label for="email" class="form-label" style="font-weight: 500;">Email pengguna</label>
                                <input type="text" class="form-control" id="email" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="harga_sewa" value="<?= set_value('email_pengguna', $pengguna['email_pengguna']); ?>" readonly>
                            </div>
                            
                            <!-- Berat -->
                            <div class="mb-3">
                                <label for="alamat" class="form-label" style="font-weight: 500;">Alamat Pengguna</label>
                                <input type="text" class="form-control" id="alamat" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="berat_pengguna" value="<?php echo set_value('alamat', $pengguna['alamat']); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label for="ktp" class="form-label" style="font-weight: 500;">No. KTP</label>
                                <input type="text" class="form-control" id="ktp" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="berat_pengguna" value="<?php echo set_value('no_ktp', $pengguna['no_ktp']); ?>" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label for="hp" class="form-label" style="font-weight: 500;">No. HP</label>
                                <input type="text" class="form-control" id="hp" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="berat_pengguna" value="<?php echo set_value('no_hp', $pengguna['no_hp']); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label for="hp" class="form-label" style="font-weight: 500;">Kabupaten/Kota</label>
                                <input type="text" class="form-control" id="hp" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="berat_pengguna" value="<?php echo set_value('nama_kab_pengguna', $pengguna['nama_kab_pengguna']); ?>" readonly>
                            </div>

                            <div class="text-center mt-4">
                                <a href="<?php echo site_url('pengguna')?>" class="btn w-100" style="background-color: #187444; color: #fff; padding: 0.75rem; font-size: 1rem; font-weight: bold; text-transform: uppercase; border-radius: 5px;">
                                    Kembali
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>
