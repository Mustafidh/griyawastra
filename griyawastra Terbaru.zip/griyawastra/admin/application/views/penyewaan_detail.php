<div class="app-wrapper">
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">
            <div class="row g-3 mb-4 align-items-center justify-content-between">
                <div class="col-auto">
                    <h1 class="app-page-title mb-0">Penyewaan Detail</h1>
                </div>
                <div class="col-auto">
                    <div class="page-utilities">
                        <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
                            <div class="col-auto">
                                <form class="table-search-form row gx-1 align-items-center">
                                    <div class="col-auto">
                                        <input type="text" id="search-orders" name="searchorders" class="form-control search-orders" placeholder="Search">
                                    </div>
                                    <div class="col-auto">
                                        <button type="submit" class="btn app-btn-secondary">Search</button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-auto">                            
                                <a class="btn app-btn-secondary" href="#">Keluar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <main>
                <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; border-radius: 15px;">
                    <div class="mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 600px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                        <h2 class="form-title mt-2 mb-4 text-center" style="font-weight: bold; font-size: 1.5rem;">Detail Pengguna</h2>
                        <form action="<?= site_url('penyewaan/simpan'); ?>" method="POST">
                            <div class="mb-3">
                                <label for="nama_pengguna" class="form-label" style="font-weight: 500;">Nama pengguna</label>
                                <input type="text" class="form-control" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="nama_pengguna" value="<?= set_value('nama_pengguna', $penyewaan['nama_pengguna']); ?>" readonly>
                            </div>
                            <!-- Input hidden untuk ID Penyewaan -->
                            <input type="hidden" name="id_penyewaan" value="<?= set_value('id_penyewaan', $penyewaan['id_penyewaan']); ?>">

                            
                            <!-- Harga/Hari -->
                            <div class="mb-3">
                                <label for="email" class="form-label" style="font-weight: 500;">Kode Transaksi</label>
                                <input type="text" class="form-control" id="email" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="" value="<?= set_value('kode_transaksi', $penyewaan['kode_transaksi']); ?>" readonly>
                            </div>
                            
                            <!-- Berat -->
                            <div class="mb-3">
                                <label for="alamat" class="form-label" style="font-weight: 500;">Tanggal Penyewaan</label>
                                <input type="text" class="form-control" id="alamat" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="" value="<?php echo set_value('tgl_penyewaan', date('d-m-Y', strtotime($penyewaan['tgl_penyewaan']))); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label for="ktp" class="form-label" style="font-weight: 500;">Tanggal Kembali</label>
                                <input type="text" class="form-control" id="ktp" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="" value="<?php echo set_value('tgl_penyewaan', date('d-m-Y', strtotime($penyewaan['tgl_kembali']))); ?>" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label for="hp" class="form-label" style="font-weight: 500;">Durasi Sewa</label>
                                <input type="text" class="form-control" id="hp" placeholder="" style="border-radius: 5px; border: 1px solid #ddd;" name="" value="<?php echo set_value('durasi_sewa', $penyewaan['durasi_sewa']); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label for="nama_ekspedisi" class="form-label" style="font-weight: 500;">Nama Ekspedisi</label>
                                <input type="text" class="form-control" id="nama_ekspedisi" 
                                    placeholder="" 
                                    style="border-radius: 5px; border: 1px solid #ddd;" 
                                    name="nama_ekspedisi" 
                                    value="<?php echo set_value('nama_ekspedisi', $penyewaan['nama_ekspedisi']); ?>" 
                                    readonly>
                            </div>
                            <div class="mb-3">
                                <label for="biaya_ekspedisi" class="form-label" style="font-weight: 500;">Biaya Ekspedisi</label>
                                <input type="text" class="form-control" id="biaya_ekspedisi" 
                                    placeholder="Masukkan Biaya Ekspedisi" 
                                    style="border-radius: 5px; border: 1px solid #ddd;" 
                                    name="biaya_ekspedisi" 
                                    value="<?php echo set_value('biaya_ekspedisi', $penyewaan['biaya_ekspedisi']); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="resi_ekspedisi" class="form-label" style="font-weight: 500;">Resi Ekspedisi</label>
                                <input type="text" class="form-control" id="resi_ekspedisi" 
                                    placeholder="Masukkan Resi Ekspedisi" 
                                    style="border-radius: 5px; border: 1px solid #ddd;" 
                                    name="resi_ekspedisi" 
                                    value="<?php echo set_value('resi_ekspedisi', $penyewaan['resi_ekspedisi']); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="estimasi_ekspedisi" class="form-label" style="font-weight: 500;">Estimasi Ekspedisi</label>
                                <input type="text" class="form-control" id="estimasi_ekspedisi" 
                                    placeholder="Masukkan Estimasi Ekspedisi" 
                                    style="border-radius: 5px; border: 1px solid #ddd;" 
                                    name="estimasi_ekspedisi" 
                                    value="<?php echo set_value('estimasi_ekspedisi', $penyewaan['estimasi_ekspedisi']); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="total_harga" class="form-label" style="font-weight: 500;">Total Harga</label>
                                <input type="text" class="form-control" id="total_harga" 
                                    placeholder="Total Harga" 
                                    style="border-radius: 5px; border: 1px solid #ddd;" 
                                    name="total_harga" 
                                    value="Rp. <?php echo set_value('total_harga', number_format($penyewaan['total_harga'])); ?>" 
                                    readonly>
                            </div>


                            <div class="mb-3">
                                <label for="status_penyewaan" class="form-label" style="font-weight: 500;">Status Penyewaan</label>
                                <select class="form-select" name="status_penyewaan" id="status_penyewaan" 
                                        style="border-radius: 5px; border: 1px solid #ddd;">
                                    <option value="">Pilih Status Penyewaan</option>
                                    <?php if (!empty($status_enum)): ?>
                                        <?php foreach ($status_enum as $status): ?>
                                            <option 
                                                value="<?= $status; ?>" 
                                                <?= isset($penyewaan['status_penyewaan']) && $status == $penyewaan['status_penyewaan'] ? 'selected' : ''; ?>>
                                                <?= $status; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <option value="">Data status tidak tersedia</option>
                                    <?php endif; ?>
                                </select>
                            </div>



                        
                            <div class="text-center mt-4">
                                <button type="submit" class="btn w-100" style="background-color: #187444; color: #fff; padding: 0.75rem; font-size: 1rem; font-weight: bold; text-transform: uppercase; border-radius: 5px;">
                                    Perbarui
                                    </button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>
