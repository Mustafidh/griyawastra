<div class="app-wrapper">
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4">
		    <div class="container-xl">
			    
			    <div class="row g-3 mb-4 align-items-center justify-content-between">
				    <div class="col-auto">
			            <h1 class="app-page-title mb-0">Daftar Penyewaan</h1>
				    </div>
				    <div class="col-auto">
					     <div class="page-utilities">
						    <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							    <div class="col-auto">
								    <form class="table-search-form row gx-1 align-items-center">
					                    <div class="col-auto">
					                        <input type="text" id="search-orders" name="searchorders" class="form-control search-orders" placeholder="Search">
					                    </div>
					                    <div class="col-auto">
					                        <button type="submit" class="btn app-btn-secondary">Search</button>
					                    </div>
					                </form>
					                
							    </div><!--//col-->
						
							    <div class="col-auto">						    
								    <a class="btn app-btn-secondary" href="<?php echo base_url("inventaris/tambah")?>">
									    Cetak
									</a>
							    </div>
						    </div><!--//row-->
					    </div><!--//table-utilities-->
				    </div><!--//col-auto-->
			    </div><!--//row-->
				
				
				<div class="tab-content" id="orders-table-tab-content">
			        <div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
					    <div class="app-card app-card-orders-table shadow-sm mb-5">
						    <div class="app-card-body">
							    <div class="table-responsive">
							        <table class="table app-table-hover mb-0 text-center">
										<thead>
											<tr>
                                            <th class="cell">No</th>
                                            <th class="cell">Nama Penyewa</th>
                                            <th class="cell">Kode Transaksi</th>
                                            <th class="cell">Tgl Penyewaan</th>
                                            <th class="cell">Tgl Kembali</th>
                                            <th class="cell">Durasi Sewa</th>
                                            <th class="cell">Status</th>
                                            <th class="cell">Nama Ekspedisi</th>
                                            <th class="cell">Total Harga</th>
                                            <th class="cell">Opsi</th>
											</tr>
										</thead>
										<tbody>
                                        <?php foreach ($penyewaan as $k => $v) : ?>
											<tr>
												<td class="cell"><?php echo $k+1; ?></td>
												<td class="cell"><?php echo $v['nama_pengguna']; ?></td>
												<td class="cell"><?php echo $v['kode_transaksi']; ?></td>
												<td class="cell"><?php echo date('d-m-Y', strtotime($v['tgl_penyewaan'])); ?></td>
												<td class="cell"><?php echo date('d-m-Y', strtotime($v['tgl_kembali'])); ?></td>
												<td class="cell"><?php echo $v['durasi_sewa']; ?></td>
												<td class="cell">
													<?php 
														$status = $v['status_penyewaan'];
														$badge_class = ''; // Kelas default badge

														// Tentukan warna badge berdasarkan status
														switch ($status) {
															case 'Belum Bayar':
																$badge_class = 'badge bg-danger'; // Merah
																break;
															case 'Diproses':
																$badge_class = 'badge bg-info';
																break;
															case 'Dikirim':
																$badge_class = 'badge bg-warning'; // Biru
																break;
															case 'Disewa':
																$badge_class = 'badge bg-secondary'; // Biru Muda
																break;
															case 'Proses Verifikasi':
																$badge_class = 'badge bg-warning'; // Abu-abu
																break;
															case 'Diverifikasi':
																$badge_class = 'badge bg-success'; // Hijau
																break;
															case 'Selesai':
																$badge_class = 'badge bg-success'; // Hitam
																break;
															case 'Dibatalkan':
																$badge_class = 'badge bg-danger'; // Merah
																break;
															default:
																$badge_class = 'badge bg-secondary'; // Default
																break;
														}
													?>
							
													<span class="<?php echo $badge_class; ?>"><?php echo $status; ?></span>
												</td>
												<td class="cell"><?php echo $v['nama_ekspedisi']; ?></td>
												<td class="cell">Rp. <?php echo number_format($v['total_harga']); ?></td>
												<td class="cell">
													<a class="btn btn-sm btn-warning me-1 py-2 mb-1 px-3 fw-bold text-white" href="<?php echo base_url("penyewaan/detail/".$v["id_penyewaan"] )?>">Detail</a>
													<a class="btn btn-sm btn-info me-1 py-2 mb-1 px-3 fw-bold text-white" href="<?php echo base_url("penyewaan/pengembalian/".$v["id_penyewaan"] )?>">Pengembalian</a>
												</td>
											</tr>
											<?php endforeach ?>
										</tbody>
									</table>
						        </div><!--//table-responsive-->
						       
						    </div><!--//app-card-body-->		
						</div><!--//app-card-->
						<nav class="app-pagination">
							<ul class="pagination justify-content-center">
								<li class="page-item disabled">
									<a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
							    </li>
								<li class="page-item active"><a class="page-link" href="#">1</a></li>
								<li class="page-item"><a class="page-link" href="#">2</a></li>
								<li class="page-item"><a class="page-link" href="#">3</a></li>
								<li class="page-item">
								    <a class="page-link" href="#">Next</a>
								</li>
							</ul>
						</nav><!--//app-pagination-->
						
			        </div><!--//tab-pane-->
			        
			        
				
			    
		    </div><!--//container-fluid-->
	    </div><!--//app-content-->