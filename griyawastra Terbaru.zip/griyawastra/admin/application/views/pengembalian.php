<div class="app-wrapper">
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">

            <main>
                <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 20px; border-radius: 15px;">
                    <div class="mb-5 p-5 bg-white rounded shadow-sm" style="width: 100%; max-width: 600px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                        <h2 class="form-title mt-2 mb-4 text-center" style="font-weight: bold; font-size: 1.5rem;">Pengembalian</h2>
                        <form action="<?= site_url('penyewaan/pengembalian'); ?>" method="POST">
                            <!-- Input hidden untuk ID Penyewaan -->
                            <input type="hidden" name="id_penyewaan" value="<?= $penyewaan['id_penyewaan']; ?>">

                            <!-- Kode Transaksi -->
                            <div class="mb-3">
                                <label for="email" class="form-label" style="font-weight: 500;">Kode Transaksi</label>
                                <input type="text" class="form-control" name="" value="<?= set_value('kode_transaksi', $penyewaan['kode_transaksi']); ?>" readonly>
                            </div>

                            <!-- Nama Ekspedisi -->
                            <div class="mb-3">
                                <label for="nama_ekspedisi" class="form-label" style="font-weight: 500;">Nama Ekspedisi</label>
                                <input type="text" class="form-control" name="nama_ekspedisi" value="<?= set_value('nama_ekspedisi', $penyewaan['nama_ekspedisi']); ?>" readonly>
                            </div>

                            <!-- Biaya Ekspedisi -->
                            <div class="mb-3">
                                <label for="biaya_ekspedisi" class="form-label" style="font-weight: 500;">Biaya Ekspedisi</label>
                                <input type="text" class="form-control" name="biaya_ekspedisi" value="Rp. <?= set_value('biaya_ekspedisi', number_format($penyewaan['biaya_ekspedisi'])); ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label for="biaya_ekspedisi" class="form-label" style="font-weight: 500;">Hari Terlewat</label>
                                <input type="text" class="form-control" name="biaya_ekspedisi" value="<?= set_value('hari_terlewat', $penyewaan['hari_terlewat']); ?>" readonly>
                            </div>
                    
                            <div class="mb-3">
                                <label for="total_harga" class="form-label" style="font-weight: 500;">Denda Kerusakan</label>
                                <input type="text" class="form-control" name="denda_kerusakan" value="Rp. <?= set_value('denda_kerusakan', number_format($penyewaan['denda_kerusakan'])); ?>">
                            </div>

                            <!-- Status Penyewaan -->
                            <div class="mb-3">
                                <label for="status_penyewaan" class="form-label" style="font-weight: 500;">Status Penyewaan</label>
                                <select class="form-select" name="status_penyewaan" id="status_penyewaan" 
                                        style="border-radius: 5px; border: 1px solid #ddd;">
                                    <option value="">Pilih Status Penyewaan</option>
                                    <?php if (!empty($status_enum)): ?>
                                        <?php foreach ($status_enum as $status): ?>
                                            <option 
                                                value="<?= $status; ?>" 
                                                <?= isset($penyewaan['status_penyewaan']) && $status == $penyewaan['status_penyewaan'] ? 'selected' : ''; ?>>
                                                <?= $status; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <option value="">Data status tidak tersedia</option>
                                    <?php endif; ?>
                                </select>
                            </div>


                            <!-- Gambar Produk -->
                            <div class="mb-3">
                                <label for="foto_produk" class="form-label" style="font-weight: 500;">Gambar Kondisi</label><br>
                                <?php if (!empty($penyewaan['gambar_kondisi'])): ?>
                                    <img src="<?= $this->config->item('url_kondisi') . $penyewaan['gambar_kondisi']; ?>" alt="gambar produk" style="width: 80px; height: auto; border-radius: 5px; margin-top: 10px;" onclick="showImageModal(this);">
                                <?php endif; ?>
                            </div>

                            <!-- Tombol Perbarui -->
                            <div class="text-center mt-4">
                                <button type="submit" class="btn w-100" style="background-color: #187444; color: #fff; padding: 0.75rem; font-size: 1rem; font-weight: bold; text-transform: uppercase; border-radius: 5px;">
                                    Perbarui
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>

<div class="modal fade" id="imagePreviewModal" tabindex="-1" aria-labelledby="imagePreviewModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="imagePreviewModalLabel">Gambar Kondisi Produk</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <img id="modalImage" src="" alt="Gambar Kondisi" style="width: 100%; height: auto; border-radius: 5px;">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript untuk mengaktifkan Modal -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script>
    function showImageModal(element) {
        var imageSrc = $(element).attr('src');
        $('#modalImage').attr('src', imageSrc);
        $('#imagePreviewModal').modal('show');
    }
</script>
