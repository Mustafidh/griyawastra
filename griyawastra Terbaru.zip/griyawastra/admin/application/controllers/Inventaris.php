<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventaris extends CI_Controller {
    
   function index(){

       $this->load->model("Mproduk");

       $data["produk"] = $this->Mproduk->tampil();

       $this->load->view("templates/header");
       $this->load->view("inventaris_tampil", $data);
       $this->load->view("templates/footer");
    }

    public function tambah() {
      $this->load->model("Mproduk");
      $this->load->library('session');
      $this->load->library('form_validation');
      $this->load->library('upload');
  
      $data['kategori'] = $this->Mproduk->get_kategori();
  
      $inputan = $this->input->post();
  
      // Validasi form
      $this->form_validation->set_rules("nama_produk", "Nama Produk", "required");
      $this->form_validation->set_rules("harga_sewa", "Harga/Hari", "required|numeric");
      $this->form_validation->set_rules("berat_produk", "Berat", "required|numeric");
      $this->form_validation->set_rules("stok", "Stok", "required|integer");
      $this->form_validation->set_rules("id_kategori", "Kategori", "required");
      $this->form_validation->set_rules("deskripsi_produk", "Deskripsi", "required");
      $this->form_validation->set_message("required", "%s wajib diisi");
      $this->form_validation->set_message("numeric", "%s harus berupa angka");
      $this->form_validation->set_message("integer", "%s harus berupa angka bulat");
  
      if ($this->form_validation->run() == TRUE) {
          // Upload gambar utama
          $config['upload_path'] = $this->config->item("assets_uploads");
          $config['allowed_types'] = 'jpg|jpeg|png';
          $config['file_name'] = uniqid(); // Nama file unik
          $this->upload->initialize($config);
  
          if ($this->upload->do_upload('foto_produk')) {
              $upload_data = $this->upload->data();
              $inputan['foto_produk'] = $upload_data['file_name']; // Simpan nama file ke inputan
  
              // Simpan data produk menggunakan model
              $inputan['id_admin'] = 1; // ID admin, sesuaikan dengan session login
              $id_produk = $this->Mproduk->simpan($inputan);
  
              // Upload gambar tambahan (jika ada)
              if (!empty($_FILES['gambar_tambahan']['name'][0])) {
                  $files = $_FILES;
                  $count = count($_FILES['gambar_tambahan']['name']);
                  $gambar_tambahan = [];
  
                  for ($i = 0; $i < $count; $i++) {
                      $_FILES['file']['name'] = $files['gambar_tambahan']['name'][$i];
                      $_FILES['file']['type'] = $files['gambar_tambahan']['type'][$i];
                      $_FILES['file']['tmp_name'] = $files['gambar_tambahan']['tmp_name'][$i];
                      $_FILES['file']['error'] = $files['gambar_tambahan']['error'][$i];
                      $_FILES['file']['size'] = $files['gambar_tambahan']['size'][$i];
  
                      $this->upload->initialize($config);
                      if ($this->upload->do_upload('file')) {
                          $upload_data = $this->upload->data();
                          $gambar_tambahan[] = [
                              'nama_gambar' => $upload_data['file_name'],
                              'id_produk' => $id_produk
                          ];
                      }
                  }
  
                  // Simpan data gambar tambahan ke database
                  if (!empty($gambar_tambahan)) {
                      $this->Mproduk->simpan_gambar_tambahan($gambar_tambahan);
                  }
              }
  
              // Set pesan sukses dan redirect
              $this->session->set_flashdata('pesan_sukses', 'Data produk berhasil tersimpan');
              redirect('inventaris', 'refresh');
          } else {
              // Jika upload gambar utama gagal
              $this->session->set_flashdata('pesan_error', $this->upload->display_errors());
              redirect('inventaris/tambah');
          }
      }
  
      // Load tampilan form tambah produk
      $this->load->view("templates/header");
      $this->load->view("inventaris_tambah", $data);
      $this->load->view("templates/footer");
  }
  
      
  
       function hapus($id_produk){
  
        $this->load->model("Mproduk");
        $this->Mproduk->hapus($id_produk);
        $this->session->set_flashdata('pesan_sukses','Data produk Telah Terhapus');
        redirect('inventaris','refresh');
  
       }
  
       function edit($id_produk)
{
    // Load model, library, dan data awal
    $this->load->model("Mproduk");
    $this->load->library('session');
    $this->load->library('form_validation');

    // Data produk untuk form
    $data["produk"] = $this->Mproduk->detail($id_produk);
    $data["kategori"] = $this->Mproduk->get_kategori();

    // Data gambar tambahan
    $data["gambar_tambahan"] = $this->Mproduk->get_gambar_tambahan($id_produk);

    // Proses form ubah data
    $inputan = $this->input->post();
    $this->form_validation->set_rules("nama_produk", "Nama Produk", "required");
    $this->form_validation->set_rules("harga_sewa", "Harga/Hari", "required|numeric");
    $this->form_validation->set_rules("berat_produk", "Berat", "required|numeric");
    $this->form_validation->set_rules("stok", "Stok", "required|integer");
    $this->form_validation->set_rules("id_kategori", "Kategori", "required");
    $this->form_validation->set_rules("deskripsi_produk", "Deskripsi", "required");
    $this->form_validation->set_message("required", "%s wajib diisi");
    $this->form_validation->set_message("numeric", "%s harus berupa angka");
    $this->form_validation->set_message("integer", "%s harus berupa angka bulat");

    // Jika validasi berhasil
    if ($this->form_validation->run() == TRUE) {
        // Proses update data utama produk
        $this->Mproduk->edit($inputan, $id_produk);

        // Proses upload gambar tambahan
        $config['upload_path'] = $this->config->item("assets_uploads");
        $config['allowed_types'] = 'gif|jpg|jpeg|png';
        $config['file_name'] = uniqid(); // Nama file unik
        $this->load->library('upload', $config);

        if (!empty($_FILES['gambar_tambahan']['name'][0])) {
            $files = $_FILES['gambar_tambahan'];
            $gambar_tambahan = [];

            // Proses setiap file yang diupload
            for ($i = 0; $i < count($files['name']); $i++) {
                $_FILES['file']['name'] = $files['name'][$i];
                $_FILES['file']['type'] = $files['type'][$i];
                $_FILES['file']['tmp_name'] = $files['tmp_name'][$i];
                $_FILES['file']['error'] = $files['error'][$i];
                $_FILES['file']['size'] = $files['size'][$i];

                // Upload file
                if ($this->upload->do_upload('file')) {
                    $upload_data = $this->upload->data();
                    $gambar_tambahan[] = [
                        'id_produk' => $id_produk,
                        'nama_gambar' => $upload_data['file_name']
                    ];
                }
            }

            // Simpan data gambar tambahan ke tabel gambar_produk
            if (!empty($gambar_tambahan)) {
                $this->Mproduk->simpan_gambar_tambahan($gambar_tambahan);
            }
        }

        $this->session->set_flashdata('pesan_sukses', 'Data produk dan gambar tambahan telah diubah');
        redirect('inventaris', 'refresh');
    }

    // Load tampilan edit produk
    $this->load->view("templates/header");
    $this->load->view("inventaris_edit", $data);
    $this->load->view("templates/footer");
}

  }