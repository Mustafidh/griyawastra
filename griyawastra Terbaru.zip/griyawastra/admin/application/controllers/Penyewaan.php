<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penyewaan extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function tampil()
	{
        $this->load->model("Mpenyewaan");
        $data["penyewaan"] = $this->Mpenyewaan->tampil();

		$this->load->view('templates/header');
		$this->load->view('penyewaan_tampil', $data);
		$this->load->view('templates/footer');
	}

	public function detail($id_penyewaan) {
		$this->load->library('form_validation');
		$this->load->model("Mpenyewaan");
	
		// Ambil data dari model
		$data['penyewaan'] = $this->Mpenyewaan->getDetailPenyewaan($id_penyewaan);
		$data['status_enum'] = ['Belum Bayar','Diproses','Dikirim','Disewa','Proses Verifikasi','Diverifikasi','Selesai','Dibatalkan'];
		
	
		// Load view dengan data
		$this->load->view("templates/header");
		$this->load->view("penyewaan_detail", $data);
		$this->load->view("templates/footer");
	}

	public function simpan() {
		$this->load->model('Mpenyewaan');
        $id_penyewaan = $this->input->post('id_penyewaan');
        $data = [
            'resi_ekspedisi' => $this->input->post('resi_ekspedisi'),
            'status_penyewaan' => $this->input->post('status_penyewaan')
        ];

        // Validasi input
        $this->form_validation->set_rules('resi_ekspedisi', 'Resi Ekspedisi', 'required|max_length[50]');
        $this->form_validation->set_rules('status_penyewaan', 'Status Penyewaan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('penyewaan/detail/' . $id_penyewaan);
        } else {
            if ($this->Mpenyewaan->update_penyewaan($id_penyewaan, $data)) {
				$this->session->set_flashdata('pesan_sukses', 'Data Penyewaan telah diperbarui!');
            } else {
                $this->session->set_flashdata('pesan_gagal', 'Terjadi kesalahan saat memperbarui data.');
            }
            redirect('penyewaan/tampil');
        }
    }
	
	public function pengembalian($id_penyewaan=null)
{
    $this->load->library('form_validation');
    $this->load->model("Mpenyewaan");

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Bagian untuk menampilkan data pengembalian
        if ($id_penyewaan === null) {
            show_404();
        }

        // Ambil data dari model
        $data['penyewaan'] = $this->Mpenyewaan->get_pengembalian_by_id_penyewaan($id_penyewaan);
        $data['status_enum'] = ['Belum Bayar', 'Diproses', 'Dikirim', 'Disewa', 'Proses Verifikasi', 'Diverifikasi', 'Selesai', 'Dibatalkan'];
        echo '<pre>';
        print_r($data);
        echo '</pre>';

        $this->load->view("templates/header");
        $this->load->view("pengembalian", $data);
        $this->load->view("templates/footer");
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Bagian untuk memproses verifikasi pengembalian
        $id_penyewaan = $this->input->post('id_penyewaan');
        $status_penyewaan = $this->input->post('status_penyewaan');
		$denda_kerusakan = str_replace(['Rp.', ',', '.', ' '], '', $this->input->post('denda_kerusakan'));

        // Array data untuk disimpan
        $data_pengembalian = array(
            'denda_kerusakan' => $denda_kerusakan,
        );

        $this->db->trans_start();
        $this->Mpenyewaan->update_pengembalian($id_penyewaan, $data_pengembalian);

        $data_penyewaan = array(
            'status_penyewaan' => $status_penyewaan,
        );
        $this->Mpenyewaan->update_status_penyewaan($id_penyewaan, $data_penyewaan);
        $this->db->trans_complete();

        if ($this->db->trans_status() === FALSE) {
            $this->session->set_flashdata('pesan_gagal', 'Terjadi kesalahan saat memperbarui data.');
        } else {
            $this->session->set_flashdata('pesan_sukses', 'Data Pengembalian telah diperbarui!');
        }

        redirect('penyewaan/tampil');
    } else {
        // Jika bukan GET atau POST
        show_404();
    }
}

	
}
