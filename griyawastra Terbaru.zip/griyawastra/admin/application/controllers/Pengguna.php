<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
        $this->load->model("Mpengguna");
        $data["pengguna"] = $this->Mpengguna->tampil();

		$this->load->view('templates/header');
		$this->load->view('pengguna_tampil', $data);
		$this->load->view('templates/footer');
	}

	function detail($id_pengguna){
  
        //tampil data
        $this->load->model("Mpengguna");
        $this->load->library('session');

        $data["pengguna"] = $this->Mpengguna->detail($id_pengguna);

        $this->load->view("templates/header");
        $this->load->view("pengguna_detail", $data);
        $this->load->view("templates/footer");
       }

	   function hapus($id_pengguna){
  
        $this->load->model("Mpengguna");
        $this->Mpengguna->hapus($id_pengguna);
		
        $this->session->set_flashdata('pesan_sukses','Data pengguna Telah Terhapus');
        redirect('pengguna','refresh');
  
       }
}
